import geopandas as gpd, pandas as pd
g60=gpd.read_file('shp/US_county_1860_conflated.shp')[['GISJOIN','geometry']]
s=pd.read_csv('s1860_nominal.csv',dtype={'GISJOIN':str})[['GISJOIN','enslaved','tot']]
g60=g60.merge(s,on='GISJOIN'); g60['a60']=g60.area
for y in [1900,1930]:
    g=gpd.read_file(f'shp/US_county_{y}_conflated.shp')[['GISJOIN','STATENAM','geometry']].rename(columns={'GISJOIN':'GJ'}); g['aT']=g.area
    x=gpd.overlay(g60,g,how='intersection',keep_geom_type=True); x['ia']=x.area; x['frac']=x.ia/x.a60
    x['ens']=x.enslaved*x.frac; x['pp']=x.tot*x.frac
    c=x.groupby('GJ').agg(ens=('ens','sum'),pp=('pp','sum'),ia=('ia','sum'),aT=('aT','first'),STATE=('STATENAM','first')).reset_index()
    c['S']=c.ens/c.pp; c['cover']=c.ia/c.aT
    cen=g.set_index('GJ').geometry.centroid; c['cx']=c.GJ.map(cen.x)/1000; c['cy']=c.GJ.map(cen.y)/1000
    c.rename(columns={'GJ':'GISJOIN'}).to_csv(f'S1860_on_{y}.csv',index=False); print(y,len(c),round(c.ens.sum()))
