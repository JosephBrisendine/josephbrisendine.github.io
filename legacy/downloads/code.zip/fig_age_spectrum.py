import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
r=pd.read_csv('age_spectrum_stable.csv'); r=r[r.t!=2024]
ramp=['#9ec5f4','#6da7ec','#3987e5','#256abf','#1c5cab','#104281','#0d366b']
cm=LinearSegmentedColormap.from_list('b',ramp[::-1])
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11})
fig,ax=plt.subplots(figsize=(10,5.6),dpi=150,facecolor='#fcfcfb'); ax.set_facecolor('#fcfcfb')
T=sorted(r.t0.unique())
for t0 in T:
    d=r[r.t0==t0].sort_values('lag'); c=cm((t0-1870)/(2020-1870))
    lw=3 if t0==1870 else 1.6
    ax.plot(d.lag,d.s_amp,color='#c0392b' if t0==1870 else c,lw=lw,solid_capstyle='round')
    if t0 in (1870,1900,1950,1970):
        e=d.iloc[-1]; ax.text(e.lag+2,e.s_amp,str(t0),va='center',fontsize=10,color='#14171a')
ax.axhline(1,color='#898781',lw=1,ls=(0,(4,3)))
ax.set_xlabel('Years since the new pattern appeared'); ax.set_ylabel('Share of it still present\n(relative to regional average)')
fig.text(0.07,0.955,"Each decade's new piece of the Black-population map, followed forward",fontsize=13.5,color='#14171a',weight='bold')
fig.text(0.07,0.875,"606 Southern counties with boundaries unchanged since 1860. Darker blue = older decade.\nRed: the 1865–70 resettlement right after emancipation.",fontsize=9.5,color='#4f555c')
for s in ['top','right']: ax.spines[s].set_visible(False)
for s in ['left','bottom']: ax.spines[s].set_color('#c9ccd0')
ax.grid(axis='y',color='#e6e8eb',lw=.8); ax.set_xlim(0,165); ax.set_ylim(0.3,2.7)
fig.tight_layout(rect=(0,0,1,0.84)); fig.savefig('site/age_spectrum_residence.png',facecolor='#fcfcfb'); print('ok')
