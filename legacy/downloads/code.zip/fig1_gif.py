import json,re,numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
from matplotlib.colors import LinearSegmentedColormap
import imageio.v2 as imageio
D=json.load(open('fig1.json'))
def polys(d):
    out=[]
    for part in d.split('Z'):
        pts=re.findall(r'(-?\d+\.?\d*),(-?\d+\.?\d*)',part)
        if len(pts)>=3: out.append(np.array(pts,float))
    return out
cp=[];own=[]
for i,d in enumerate(D['paths']):
    for p in polys(d): cp.append(p); own.append(i)
own=np.array(own)
sp=[p for d in D['states'] for p in polys(d)]
cmap=LinearSegmentedColormap.from_list('b',['#eef4fc','#cde2fb','#9ec5f4','#6da7ec','#3987e5','#256abf','#1c5cab','#104281','#0d366b'])
m70=D['means']['1870']; VMAX=0.8; RMAX=VMAX/m70
b=np.array([np.nan if x is None else x for x in D['vals']['1870']])
plt.rcParams['font.family']='DejaVu Sans'
years=[y for y in D['years'] if y<1965 or y in (1970,1980,1990,2000,2010,2020,2024)]
frames=[]
for y in years:
    v=np.array([np.nan if x is None else x for x in D['vals'][str(y)]]); m=D['means'][str(y)]
    ok=~np.isnan(v)&~np.isnan(b); r=np.corrcoef(v[ok],b[ok])[0,1]
    fig,axs=plt.subplots(1,2,figsize=(12,4.6),dpi=90,facecolor='#fcfcfb')
    for ax,vals,ttl in [(axs[0],v/VMAX,'Black share of each county'),(axs[1],(v/m)/RMAX,"Each county ÷ the South's average that year")]:
        c=[('#e9ebee' if np.isnan(x) else cmap(float(min(max(x,0.0),1.0)))) for x in vals[own]]
        ax.add_collection(PolyCollection(cp,facecolors=c,edgecolors='none'))
        ax.add_collection(PolyCollection(sp,facecolors='none',edgecolors='white',linewidths=.6))
        ax.set_xlim(0,D['W']);ax.set_ylim(D['H'],0);ax.set_aspect('equal');ax.axis('off')
        ax.set_title(ttl,fontsize=13,loc='left',color='#14171a')
    fig.text(.5,.06,f'{y}',ha='center',fontsize=30,family='DejaVu Sans Mono',color='#14171a')
    fig.text(.06,.05,f'Average county Black share {m*100:.1f}%',fontsize=11,color='#4f555c')
    fig.text(.94,.05,f'Pattern match with 1870: {r:.2f}',fontsize=11,color='#4f555c',ha='right')
    fig.subplots_adjust(left=.01,right=.99,top=.92,bottom=.12,wspace=.02)
    fig.canvas.draw(); frames.append(np.asarray(fig.canvas.buffer_rgba())[...,:3].copy()); plt.close(fig)
dur=[700]*len(frames); dur[0]=1800; dur[-1]=3000
imageio.mimsave('site/map-that-wont-let-go.gif',frames,duration=dur,loop=0)
imageio.imwrite('site/map-1870.png',frames[0]); imageio.imwrite('site/map-2024.png',frames[-1])
print(len(frames))
