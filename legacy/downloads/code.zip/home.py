import pandas as pd, numpy as np, geopandas as gpd, glob
rng=np.random.default_rng(6)
SS=['Alabama','Arkansas','Delaware','Florida','Georgia','Kentucky','Louisiana','Maryland','Mississippi','Missouri','North Carolina','South Carolina','Tennessee','Texas','Virginia','West Virginia']
FIPS={'01':'Alabama','05':'Arkansas','10':'Delaware','12':'Florida','13':'Georgia','21':'Kentucky','22':'Louisiana','24':'Maryland','28':'Mississippi','29':'Missouri','37':'North Carolina','45':'South Carolina','47':'Tennessee','48':'Texas','51':'Virginia','54':'West Virginia'}
def base(y):
    if y==2020:
        b=pd.read_csv('S1860_on_2020.csv',dtype={'GISJOIN':str}).rename(columns={'S20':'S'})
        g=gpd.read_file('shp/US_county_2020.shp',columns=['GISJOIN','STATEFP']); g['cx']=g.geometry.centroid.x/1000; g['cy']=g.geometry.centroid.y/1000
        b=b.merge(g.drop(columns='geometry'),on='GISJOIN'); b['STATE']=b.STATEFP.map(FIPS)
    else: b=pd.read_csv(f'S1860_on_{y}.csv',dtype={'GISJOIN':str})
    b=b.merge(pd.read_csv(f'cotton_{y}.csv',dtype={'GISJOIN':str}),on='GISJOIN')
    b=b[b.STATE.isin(SS)&(b.cover>=0.9)&b.S.notna()&b.cotton.notna()].reset_index(drop=True)
    b['cz']=(b.cotton-b.cotton.mean())/b.cotton.std()
    D=np.sqrt((b.cx.values[:,None]-b.cx.values[None])**2+(b.cy.values[:,None]-b.cy.values[None])**2)
    N=np.linalg.cholesky(np.exp(-D/180)+1e-6*np.eye(len(D)))@rng.standard_normal((len(D),300))
    return b,N,dict(zip(b.GISJOIN,range(len(b))))
B={2020:base(2020)}
for y,(b,_,_) in B.items():
    r=np.corrcoef(b.S,b.cotton)[0,1]; print(f'{y}: n={len(b)} corr(S,cotton)={r:.2f}')
def reg(v,Z,y,w=None):
    w=np.ones(len(y)) if w is None else w; sw=np.sqrt(w)
    X=np.column_stack([v,Z])*sw[:,None]; yy=y*sw; bb=np.linalg.lstsq(X,yy,rcond=None)[0]; r=yy-X@bb
    return bb[0], bb[0]/np.sqrt(r@r/(len(y)-X.shape[1])*np.linalg.pinv(X.T@X)[0,0])
def run(name,d,by,ycol,w=None,fe='STATE'):
    b,N,idx=B[by]; d=d.merge(b[['GISJOIN','STATE','S','cz']],on='GISJOIN',suffixes=('_x','')); ii=d.GISJOIN.map(idx).values
    fe_=pd.get_dummies(d[fe].astype(str),drop_first=True).values.astype(float); one=np.ones(len(d)); yv=d[ycol].values; ww=None if w is None else d[w].values.astype(float)
    out={'outcome':name,'n':len(d)}
    for lab,Z in [('no_cotton',np.column_stack([one,fe_])),('cotton',np.column_stack([one,fe_,d.cz,d.cz**2]))]:
        be,t=reg(d.S.values,Z,yv,ww); tn=np.array([reg(N[ii,k],Z,yv,ww)[1] for k in range(300)])
        out[f'beta_{lab}']=round(be,3); out[f't_{lab}']=round(t,1); out[f'noise95_{lab}']=round(np.quantile(abs(tn),.95),1)
    out['kept_%']=round(100*out['beta_cotton']/out['beta_no_cotton']); return out

res=[]
t=pd.read_csv('raw9/nhgis0009_csv/nhgis0009_ts_nominal_county.csv',encoding='latin-1',dtype={'GISJOIN':str})
for yr in [1970,1980,1990,2000,2010,2020]:
    d=pd.DataFrame({'GISJOIN':t.GISJOIN})
    bo,br,wo,wr=[pd.to_numeric(t[f'B39{c}{yr}'],errors='coerce') for c in ['AB','AF','AA','AE']]
    d['black_home']=bo/(bo+br); d['white_home']=wo/(wo+wr); d['gap']=d.white_home-d.black_home; d['nb']=bo+br
    d=d[d.nb>=50]
    for col in ['black_home','gap']:
        r=run(f'{col} {yr}',d[['GISJOIN',col]].dropna(),2020,col); r['mean']=round(d[col].mean(),3); res.append(r)
r=pd.DataFrame(res); print(r.to_string(index=False)); r.to_csv('home_results.csv',index=False)
# robustness: add log population density (same year) to cotton spec
g=gpd.read_file('shp/US_county_2020.shp',columns=['GISJOIN']); g['km2']=g.area/1e6
ts=pd.read_csv(glob.glob('/mnt/user-data/uploads/*ts_nominal_county.csv')[0],encoding='latin-1',dtype=str)
b,N,idx=B[2020]
for yr in [1970,1990,2020]:
    d=pd.DataFrame({'GISJOIN':t.GISJOIN}); bo,br,wo,wr=[pd.to_numeric(t[f'B39{c}{yr}'],errors='coerce') for c in ['AB','AF','AA','AE']]
    d['black_home']=bo/(bo+br); d['gap']=wo/(wo+wr)-d.black_home; d=d[(bo+br)>=50]
    pop=ts[ts.YEAR==str(yr)][['GISJOIN','A00AA']]; d=d.merge(pop,on='GISJOIN').merge(g.drop(columns='geometry'),on='GISJOIN').merge(b[['GISJOIN','STATE','S','cz']],on='GISJOIN')
    d['ld']=np.log(pd.to_numeric(d.A00AA)/d.km2); ii=d.GISJOIN.map(idx).values
    Z=np.column_stack([np.ones(len(d)),pd.get_dummies(d.STATE,drop_first=True).values.astype(float),d.cz,d.cz**2,d.ld,d.ld**2])
    for col in ['black_home','gap']:
        be,tt=reg(d.S.values,Z,d[col].values); tn=np.array([reg(N[ii,k],Z,d[col].values)[1] for k in range(300)])
        print(yr,col,'beta(+density)=',round(be,3),'t=',round(tt,1),'noise95=',round(np.quantile(abs(tn),.95),1))
