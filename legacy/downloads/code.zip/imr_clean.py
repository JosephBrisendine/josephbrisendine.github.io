import pandas as pd, numpy as np, glob
rng=np.random.default_rng(3)
OK=['Alabama','Delaware','Florida','Georgia','Louisiana','Maryland','Mississippi','North Carolina','South Carolina']
v=pd.read_csv('imr_1959_72.csv',dtype={'GISJOIN':str}); s=pd.read_csv('s1860_nominal.csv',dtype={'GISJOIN':str})
s=s[s.STATE.isin(OK)&s.S.notna()]
m=v.merge(s[['GISJOIN','STATE','S']],on='GISJOIN')
m['grp']=pd.cut(m.S,[-.01,.25,.50,1.0],labels=['low','mid','high'])
g=m.groupby(['year','grp'],observed=True)[['bn','dn','bw','dw']].sum()
g['imr_n']=1000*g.dn/g.bn; g['imr_w']=1000*g.dw/g.bw
t=g[['imr_n','imr_w']].unstack().round(1); print(t.to_string()); t.to_csv('imr_terciles.csv')
print(m.groupby('grp',observed=True).GISJOIN.nunique())
# county beta per year, Black IMR (per 1000), counties with >=50 nonwhite births
c=pd.read_csv(glob.glob('/mnt/user-data/uploads/*ds181_2010_county.csv')[0],encoding='latin-1',dtype={'GISJOIN':str})[['GISJOIN','INTPTLAT','INTPTLON']]
base=s.merge(c,on='GISJOIN').reset_index(drop=True)
R=6371; la=np.radians(base.INTPTLAT.values); lo=np.radians(base.INTPTLON.values)
x=R*np.cos(la.mean())*lo; y=R*la; D=np.sqrt((x[:,None]-x[None])**2+(y[:,None]-y[None])**2)
Ch=np.linalg.cholesky(np.exp(-D/180)+1e-6*np.eye(len(D))); noise=Ch@rng.standard_normal((len(D),400)); idx=dict(zip(base.GISJOIN,range(len(base))))
def reg(vv,Z,yv,w):
    sw=np.sqrt(w); X=np.column_stack([vv,Z])*sw[:,None]; yy=yv*sw; b=np.linalg.lstsq(X,yy,rcond=None)[0]; r=yy-X@b
    se=np.sqrt(r@r/(len(yv)-X.shape[1])*np.linalg.pinv(X.T@X)[0,0]); return b[0],b[0]/se
res=[]
for yr,d in m[m.bn>=50].groupby('year'):
    d=d[d.GISJOIN.isin(idx)]; Z=np.column_stack([np.ones(len(d)),pd.get_dummies(d.STATE,drop_first=True).values.astype(float)]); ii=d.GISJOIN.map(idx).values
    yv=1000*d.dn.values/d.bn.values; w=d.bn.values.astype(float)
    b,tt=reg(d.S.values,Z,yv,w); tn=np.array([reg(noise[ii,k],Z,yv,w)[1] for k in range(400)])
    res.append(dict(year=yr,n=len(d),beta=round(b,1),t=round(tt,2),noise95=round(np.quantile(abs(tn),.95),2),half=round(np.quantile(abs(tn),.95)*abs(b/tt),1)))
r=pd.DataFrame(res); print(r.to_string(index=False)); r.to_csv('imr_beta_6072.csv',index=False)
# pooled periods: same noise draw per county across years
def pooled(yrs):
    d=m[(m.bn>=50)&m.year.isin(yrs)&m.GISJOIN.isin(idx)]
    Z=np.column_stack([np.ones(len(d)),pd.get_dummies(d.STATE.astype(str)+d.year.astype(str),drop_first=True).values.astype(float)])
    ii=d.GISJOIN.map(idx).values; yv=1000*d.dn.values/d.bn.values; w=d.bn.values.astype(float)
    b,tt=reg(d.S.values,Z,yv,w); tn=np.array([reg(noise[ii,k],Z,yv,w)[1] for k in range(400)])
    return round(b,1),round(tt,2),round(np.quantile(abs(tn),.95),2),round((abs(tn)>=abs(tt)).mean(),3)
for nm,yrs in [('1960-65',range(1960,1966)),('1967-72',range(1967,1973))]: print(nm,pooled(yrs))
