import pandas as pd, numpy as np, geopandas as gpd
rng=np.random.default_rng(15)
R='/home/claude/dl/flood/112749-V1/Replication_AER-2012-0980/Generate_Data/redcross_new.txt'
d=pd.read_csv(R,sep='\t',encoding='latin-1'); d['fl']=pd.to_numeric(d.flooded_acres,errors='coerce').fillna(0)
d['fips']=d.fips.astype(int).astype(str).str.zfill(5); d['GISJOIN']='G'+d.fips.str[:2]+'0'+d.fips.str[2:]+'0'
g30=gpd.read_file('shp/US_county_1930_conflated.shp')[['GISJOIN','geometry']]
g20=gpd.read_file('shp/US_county_2020.shp')[['GISJOIN','STATEFP','geometry']]; g30=g30.to_crs(g20.crs)
x=g30.merge(d[['GISJOIN','fl']],on='GISJOIN',how='inner'); print('matched 1930 counties',len(x),'of',len(d),'flooded',(x.fl>0).sum())
x['fshare']=np.minimum(1,x.fl*4046.86/x.area)
o=gpd.overlay(x[['fshare','geometry']],g20.rename(columns={'GISJOIN':'G20'}),how='intersection',keep_geom_type=True); o['ia']=o.area
T=o.groupby('G20').apply(lambda z: pd.Series({'flood':np.average(z.fshare,weights=z.ia),'cov':z.ia.sum()}),include_groups=False).reset_index().rename(columns={'G20':'GISJOIN'})
T=T.merge(g20.assign(a=g20.area)[['GISJOIN','a']],on='GISJOIN'); T=T[T['cov']/T.a>=0.8]; T['flooded']=(T.flood>0).astype(float)
print('2020 counties',len(T),'any flood',int(T.flooded.sum()),'mean share among flooded',round(T[T.flood>0].flood.mean(),2))
g20['cx']=g20.centroid.x/1000; g20['cy']=g20.centroid.y/1000
P=pd.read_csv('panel2020.csv',dtype={'GISJOIN':str}); F=pd.read_csv('farmval2020.csv',dtype={'GISJOIN':str})
L=pd.concat([P[['GISJOIN','year','bshare']].rename(columns={'bshare':'y'}).assign(out='bshare'),P[['GISJOIN','year','logdens']].rename(columns={'logdens':'y'}).assign(out='logdens'),F.rename(columns={'lfv':'y'}).assign(out='lfv')])
YRS={'bshare':[1900,1910,1920,1930,1940,1950,1960,1970,1980,1990,2000,2010,2020,2024],'logdens':[1900,1910,1920,1930,1940,1950,1960,1970,1980,1990,2000,2010,2020,2024],'lfv':[1900,1910,1920,1925,1930,1935,1940,1945,1950,1954,1959]}
b=g20.drop(columns='geometry').merge(T[['GISJOIN','flood','flooded']],on='GISJOIN')
b=b[b.STATEFP.isin(['05','22','28','47','21','29'])]
b=b.merge(pd.read_csv('S1860_on_2020.csv',dtype={'GISJOIN':str})[['GISJOIN','S20']],on='GISJOIN').merge(pd.read_csv('cotton_2020.csv',dtype={'GISJOIN':str}),on='GISJOIN')
for out,y,nm in [('bshare',1920,'b20'),('logdens',1920,'d20'),('lfv',1925,'v25')]:
    b=b.merge(L[(L.out==out)&(L.year==y)][['GISJOIN','y']].rename(columns={'y':nm}),on='GISJOIN')
b=b.dropna().reset_index(drop=True); b['cz']=(b.cotton-b.cotton.mean())/b.cotton.std(); print('sample',len(b),'flooded',int(b.flooded.sum()))
D=np.sqrt((b.cx.values[:,None]-b.cx.values[None])**2+(b.cy.values[:,None]-b.cy.values[None])**2)
N=np.linalg.cholesky(np.exp(-D/180)+1e-6*np.eye(len(b)))@rng.standard_normal((len(b),300)); idx=dict(zip(b.GISJOIN,range(len(b))))
fe=pd.get_dummies(b.STATEFP,drop_first=True).values.astype(float)
def reg(v,Z,y):
    X=np.column_stack([v,Z]); c=np.linalg.lstsq(X,y,rcond=None)[0]; r=y-X@c
    return c[0], c[0]/np.sqrt(r@r/(len(y)-X.shape[1])*np.linalg.pinv(X.T@X)[0,0])
res=[]
for tr in ['flood','flooded']:
  for out,yrs in YRS.items():
    for y in yrs:
        d=b.merge(L[(L.out==out)&(L.year==y)][['GISJOIN','y']],on='GISJOIN').dropna(subset=['y']); ii=d.GISJOIN.map(idx).values
        Z=np.column_stack([np.ones(len(d)),fe[ii],d.S20,d.cz,d.cz**2,d.b20,d.d20,d.v25])
        be,t=reg(d[tr].values,Z,d.y.values); tn=np.array([reg(N[ii,k],Z,d.y.values)[1] for k in range(300)])
        res.append(dict(treat=tr,outcome=out,year=y,beta=be,t=t,noise95=np.quantile(abs(tn),.95)))
r=pd.DataFrame(res); r.to_csv('flood_results.csv',index=False); r['sig']=np.where(abs(r.t)>r.noise95,'*','')
for tr,dd in r.groupby('treat'):
    print('\n###',tr); print(dd.assign(cell=dd.beta.round(3).astype(str)+' ('+dd.t.round(1).astype(str)+'/'+dd.noise95.round(1).astype(str)+')'+dd.sig).pivot(index='year',columns='outcome',values='cell').to_string())
