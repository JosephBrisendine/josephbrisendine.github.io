import pandas as pd, numpy as np, geopandas as gpd, glob
rng=np.random.default_rng(6)
SS=['Alabama','Arkansas','Delaware','Florida','Georgia','Kentucky','Louisiana','Maryland','Mississippi','Missouri','North Carolina','South Carolina','Tennessee','Texas','Virginia','West Virginia']
FIPS={'01':'Alabama','05':'Arkansas','10':'Delaware','12':'Florida','13':'Georgia','21':'Kentucky','22':'Louisiana','24':'Maryland','28':'Mississippi','29':'Missouri','37':'North Carolina','45':'South Carolina','47':'Tennessee','48':'Texas','51':'Virginia','54':'West Virginia'}
def base(y):
    if y==2020:
        b=pd.read_csv('S1860_on_2020.csv',dtype={'GISJOIN':str}).rename(columns={'S20':'S'})
        g=gpd.read_file('shp/US_county_2020.shp',columns=['GISJOIN','STATEFP']); g['cx']=g.geometry.centroid.x/1000; g['cy']=g.geometry.centroid.y/1000
        b=b.merge(g.drop(columns='geometry'),on='GISJOIN'); b['STATE']=b.STATEFP.map(FIPS)
    else: b=pd.read_csv(f'S1860_on_{y}.csv',dtype={'GISJOIN':str})
    b=b.merge(pd.read_csv(f'cotton_{y}.csv',dtype={'GISJOIN':str}),on='GISJOIN')
    b=b[b.STATE.isin(SS)&(b.cover>=0.9)&b.S.notna()&b.cotton.notna()].reset_index(drop=True)
    b['cz']=(b.cotton-b.cotton.mean())/b.cotton.std()
    b=b.merge(pd.read_csv(f'cotton1860_on_{y}.csv',dtype={'GISJOIN':str})[['GISJOIN','cot1860']],on='GISJOIN'); b=b.merge(pd.read_csv(f'v1850_on_{y}.csv',dtype={'GISJOIN':str})[['GISJOIN','S50','cover50','cot50','wilit50_rate','wschool50_rate']],on='GISJOIN'); b=b[b.cot1860.notna()&(b.cover50>=0.9)&b.S50.notna()&b.cot50.notna()].reset_index(drop=True); b['dS']=b.S-b.S50; b['c50']=(b.cot50-b.cot50.mean())/b.cot50.std(); b['wil']=b.wilit50_rate; b['wsc']=b.wschool50_rate; b['c2']=(b.cot1860-b.cot1860.mean())/b.cot1860.std()
    D=np.sqrt((b.cx.values[:,None]-b.cx.values[None])**2+(b.cy.values[:,None]-b.cy.values[None])**2)
    N=np.linalg.cholesky(np.exp(-D/180)+1e-6*np.eye(len(D)))@rng.standard_normal((len(D),300))
    return b,N,dict(zip(b.GISJOIN,range(len(b))))

B={y:base(y) for y in [1900,2020]}
for y,(b,_,_) in B.items(): print(y,'n',len(b),'corr(S,GAEZ)',round(np.corrcoef(b.S,b.cz)[0,1],2),'corr(S,cotton1860)',round(np.corrcoef(b.S,b.c2)[0,1],2))
def reg(v,Z,y,w=None):
    w=np.ones(len(y)) if w is None else w; sw=np.sqrt(w)
    X=np.column_stack([v,Z])*sw[:,None]; yy=y*sw; bb=np.linalg.lstsq(X,yy,rcond=None)[0]; r=yy-X@bb
    return bb[0], bb[0]/np.sqrt(r@r/(len(y)-X.shape[1])*np.linalg.pinv(X.T@X)[0,0])

def fit(d,by,ycol,treat,ctrl,w=None,fe='STATE'):
    b,N,idx=B[by]; d=d.merge(b[['GISJOIN','STATE','S','S50','dS','cz','c2','c50','wil','wsc']],on='GISJOIN',suffixes=('_x','')).dropna(subset=[ycol]+treat+ctrl); ii=d.GISJOIN.map(idx).values
    F=pd.get_dummies(d[fe].astype(str),drop_first=True).values.astype(float); yv=d[ycol].values; ww=None if w is None else d[w].values.astype(float)
    out=[]
    for k,t in enumerate(treat):
        others=[d[o].values for o in treat if o!=t]
        Z=np.column_stack([np.ones(len(d)),F]+others+[d[c].values for c in ctrl]+[d[c].values**2 for c in ctrl if c in ('cz','c2','c50')])
        be,tt=reg(d[t].values,Z,yv,ww); tn=np.array([reg(N[ii,j],Z,yv,ww)[1] for j in range(150)])
        out.append(f"{t}: {be:+.3f} ({tt:.1f}/{np.quantile(abs(tn),.95):.1f})")
    return len(d),'; '.join(out)
C=['cz','c2']
rows=[]
def add(name,d,by,ycol,w=None,fe='STATE',school=False):
    n,a=fit(d,by,ycol,['S'],C,w,fe); _,b2=fit(d,by,ycol,['S'],C+['c50'],w,fe); _,c=fit(d,by,ycol,['S50','dS'],C,w,fe)
    r=dict(outcome=name,n=n,both_cotton=a,plus_1850_cotton=b2,old_vs_new=c)
    if school: _,e=fit(d,by,ycol,['S'],C+['wil','wsc'],w,fe); r['plus_1850_white_schooling']=e
    rows.append(r)
p=pd.read_csv('panel_nominal.csv',dtype={'GISJOIN':str})
add('Black share 1900',p[p.YEAR==1900][['GISJOIN','bshare']].dropna(),1900,'bshare')
ts=pd.read_csv(glob.glob('/mnt/user-data/uploads/*ts_nominal_county.csv')[0],encoding='latin-1',dtype=str); ts['bs']=pd.to_numeric(ts.B18AB)/pd.to_numeric(ts.A00AA)
add('Black share 2020',ts[ts.YEAR=='2020'][['GISJOIN','bs']].dropna(),2020,'bs')
o=pd.read_csv('outcomes_long.csv',dtype={'GISJOIN':str})
w=o.pivot_table(index=['GISJOIN','year'],columns='outcome',values='y').reset_index(); ww=o.pivot_table(index=['GISJOIN','year'],columns='outcome',values='w').reset_index()
w['own_gap']=w.white_own-w.black_own; w=w.merge(ww[['GISJOIN','year','black_own','black_illit_m21']].rename(columns={'black_own':'w_own','black_illit_m21':'w_il'}),on=['GISJOIN','year'])
d=w[(w.year==1900)&(w.w_own>=10)]; add('Farm ownership gap 1900',d[['GISJOIN','own_gap']].dropna(),1900,'own_gap')
d=w[(w.year==1900)&(w.w_il>=50)]; add('Black illiteracy 1900',d[['GISJOIN','black_illit_m21']].dropna(),1900,'black_illit_m21',school=True)
m=pd.read_csv('modern_outcomes.csv',dtype={'GISJOIN':str})
for yr in [1980,2000]:
    d=m[(m.year==yr)&(m.n_b>=50)]; add(f'High school gap {yr}',d[['GISJOIN','hs_gap']].dropna(),2020,'hs_gap',school=True)
a=pd.read_csv('raw16/nhgis0016_csv/nhgis0016_ds262_20225_county.csv',encoding='latin-1',dtype={'GISJOIN':str},low_memory=False)
hv=pd.DataFrame({'GISJOIN':a.GISJOIN,'vw':pd.to_numeric(a.AQU5E001,errors='coerce'),'vb':pd.to_numeric(a.AQU6E001,errors='coerce'),'mb':pd.to_numeric(a.AQU6M001,errors='coerce')})
hv=hv[(hv.vb>0)&(hv.vw>0)&(hv.mb/hv.vb<0.5)]; hv['lr']=np.log(hv.vb/hv.vw)
add('Black/white home value 2018-22',hv[['GISJOIN','lr']],2020,'lr')
r=pd.DataFrame(rows); pd.set_option('display.width',400); pd.set_option('display.max_colwidth',200)
for _,x in r.iterrows():
    print('\n==',x.outcome,'n=',x.n); [print('  ',k,':',x[k]) for k in r.columns[2:] if isinstance(x[k],str)]
r.to_csv('v1850_results.csv',index=False)
