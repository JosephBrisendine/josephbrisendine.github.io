# Long panel on 2020 county boundaries: black, tot, 1860-1960 (area-interpolated from NHGIS) + 1969-2024 (SEER)
import pandas as pd, numpy as np, geopandas as gpd, glob
U='/mnt/user-data/uploads/'
def rd(pat):
    f=glob.glob(U+'*'+pat); assert f,pat; return pd.read_csv(sorted(f)[0],encoding='latin-1',dtype={'GISJOIN':str})
ts=pd.read_csv(glob.glob(U+'*ts_nominal_county.csv')[0],encoding='latin-1',dtype=str)
tot=ts[['GISJOIN','YEAR','A00AA']].copy(); tot['YEAR']=tot.YEAR.astype(int); tot['tot']=pd.to_numeric(tot.A00AA,errors='coerce')
rows=[]
def add(y,df,cols):
    d=df[['GISJOIN']].copy(); d['black']=df[cols].apply(pd.to_numeric,errors='coerce').sum(axis=1); d['YEAR']=y; rows.append(d)
s60=pd.read_csv('s1860_nominal.csv',dtype={'GISJOIN':str}); d=s60[['GISJOIN']].copy(); d['black']=s60.enslaved; d['YEAR']=1860; rows.append(d)  # 1860: enslaved only
add(1870,rd('ds17_1870_county.csv'),['AK3002']); add(1880,rd('ds23_1880_county.csv'),['APP002'])
add(1890,rd('ds27_1890_county.csv'),['AV0007','AV0008']); add(1900,rd('ds31_1900_county.csv'),['AZ3003','AZ3004'])
add(1910,rd('ds37_1910_county.csv'),['A30003','A30004']); add(1920,rd('ds43_1920_county.csv'),['A8L005','A8L006'])
add(1930,rd('ds53_1930_county.csv'),['BDK003','BDK004']); add(1940,rd('ds77_1940_county.csv'),['BV2003','BV2004'])
add(1950,rd('nhgis0003_ds83_1950_county.csv'),['B1R%03d'%i for i in range(18,35)]); add(1960,rd('ds91_1960_county.csv'),['B5S002','B5S009'])
h=pd.concat(rows).merge(tot[['GISJOIN','YEAR','tot']],on=['GISJOIN','YEAR'],how='left')
h.loc[h.YEAR==1860,'tot']=h[h.YEAR==1860].GISJOIN.map(dict(zip(s60.GISJOIN,s60.tot)))
g20=gpd.read_file('shp/US_county_2020.shp')
FIPS=['01','05','10','12','13','21','22','24','28','29','37','45','47','48','51','54']
g20=g20[g20.STATEFP.isin(FIPS)][['GISJOIN','STATEFP','geometry']].reset_index(drop=True); g20['a20']=g20.area
shapes={1860:'US_county_1860_conflated',1900:'US_county_1900_conflated',1930:'US_county_1930_conflated'}
use={1860:1860,1870:1860,1880:1860,1890:1900,1900:1900,1910:1900,1920:1930,1930:1930,1940:1930,1950:1930,1960:1930}
cache={}; out=[]
for y,sy in use.items():
    if sy not in cache:
        gs=gpd.read_file(f'shp/{shapes[sy]}.shp')[['GISJOIN','geometry']].to_crs(g20.crs); gs['as_']=gs.area
        cache[sy]=gpd.overlay(gs,g20[['GISJOIN','geometry']].rename(columns={'GISJOIN':'G20'}),how='intersection',keep_geom_type=True); cache[sy]['ia']=cache[sy].area
    x=cache[sy].merge(h[h.YEAR==y][['GISJOIN','black','tot']],on='GISJOIN',how='left')
    fr=x.ia/x.as_; x['b']=x.black*fr; x['t']=x.tot*fr; x['cov']=x.ia*x.tot.notna()
    c=x.groupby('G20').agg(black=('b','sum'),tot=('t','sum'),cov=('cov','sum')).reset_index().merge(g20[['GISJOIN','a20']],left_on='G20',right_on='GISJOIN')
    c=c[(c['cov']/c.a20>=0.8)&(c.tot>0)]; c['year']=y; out.append(c[['GISJOIN','year','black','tot']]); print(y,len(c))
seer=pd.read_csv('seer_county_race.csv',dtype={'stf':str,'cty':str,'GISJOIN':str}); seer=seer[seer.stf.isin(FIPS)&(seer.year>=1969)]
out.append(seer[['GISJOIN','year','black','tot']])
p=pd.concat(out); p=p.merge(g20[['GISJOIN','a20']],on='GISJOIN'); p['bshare']=p.black/p.tot; p['logdens']=np.log(p.tot/(p.a20/1e6))
p.drop(columns='a20').to_csv('panel2020.csv',index=False); print(p.groupby('year').size().tail(3))
