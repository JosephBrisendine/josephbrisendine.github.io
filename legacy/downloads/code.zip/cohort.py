import pandas as pd, numpy as np, geopandas as gpd, glob
rng=np.random.default_rng(6)
SS=['Alabama','Arkansas','Delaware','Florida','Georgia','Kentucky','Louisiana','Maryland','Mississippi','Missouri','North Carolina','South Carolina','Tennessee','Texas','Virginia','West Virginia']
FIPS={'01':'Alabama','05':'Arkansas','10':'Delaware','12':'Florida','13':'Georgia','21':'Kentucky','22':'Louisiana','24':'Maryland','28':'Mississippi','29':'Missouri','37':'North Carolina','45':'South Carolina','47':'Tennessee','48':'Texas','51':'Virginia','54':'West Virginia'}
def base(y):
    if y==2020:
        b=pd.read_csv('S1860_on_2020.csv',dtype={'GISJOIN':str}).rename(columns={'S20':'S'})
        g=gpd.read_file('shp/US_county_2020.shp',columns=['GISJOIN','STATEFP']); g['cx']=g.geometry.centroid.x/1000; g['cy']=g.geometry.centroid.y/1000
        b=b.merge(g.drop(columns='geometry'),on='GISJOIN'); b['STATE']=b.STATEFP.map(FIPS)
    else: b=pd.read_csv(f'S1860_on_{y}.csv',dtype={'GISJOIN':str})
    b=b.merge(pd.read_csv(f'cotton_{y}.csv',dtype={'GISJOIN':str}),on='GISJOIN')
    b=b[b.STATE.isin(SS)&(b.cover>=0.9)&b.S.notna()&b.cotton.notna()].reset_index(drop=True)
    b['cz']=(b.cotton-b.cotton.mean())/b.cotton.std()
    D=np.sqrt((b.cx.values[:,None]-b.cx.values[None])**2+(b.cy.values[:,None]-b.cy.values[None])**2)
    N=np.linalg.cholesky(np.exp(-D/180)+1e-6*np.eye(len(D)))@rng.standard_normal((len(D),300))
    return b,N,dict(zip(b.GISJOIN,range(len(b))))
B={2020:base(2020)}
for y,(b,_,_) in B.items():
    r=np.corrcoef(b.S,b.cotton)[0,1]; print(f'{y}: n={len(b)} corr(S,cotton)={r:.2f}')
def reg(v,Z,y,w=None):
    w=np.ones(len(y)) if w is None else w; sw=np.sqrt(w)
    X=np.column_stack([v,Z])*sw[:,None]; yy=y*sw; bb=np.linalg.lstsq(X,yy,rcond=None)[0]; r=yy-X@bb
    return bb[0], bb[0]/np.sqrt(r@r/(len(y)-X.shape[1])*np.linalg.pinv(X.T@X)[0,0])
def run(name,d,by,ycol,w=None,fe='STATE'):
    b,N,idx=B[by]; d=d.merge(b[['GISJOIN','STATE','S','cz']],on='GISJOIN',suffixes=('_x','')); ii=d.GISJOIN.map(idx).values
    fe_=pd.get_dummies(d[fe].astype(str),drop_first=True).values.astype(float); one=np.ones(len(d)); yv=d[ycol].values; ww=None if w is None else d[w].values.astype(float)
    out={'outcome':name,'n':len(d)}
    for lab,Z in [('no_cotton',np.column_stack([one,fe_])),('cotton',np.column_stack([one,fe_,d.cz,d.cz**2]))]:
        be,t=reg(d.S.values,Z,yv,ww); tn=np.array([reg(N[ii,k],Z,yv,ww)[1] for k in range(150)])
        out[f'beta_{lab}']=round(be,3); out[f't_{lab}']=round(t,1); out[f'noise95_{lab}']=round(np.quantile(abs(tn),.95),1)
    out['kept_%']=round(100*out['beta_cotton']/out['beta_no_cotton']); return out

P='raw12/nhgis0012_csv/nhgis0012_'
def rd(k): return pd.read_csv(P+k+'_county.csv',encoding='latin-1',dtype={'GISJOIN':str},low_memory=False)
def col(df,pre,br,i): return pd.to_numeric(df[f'{pre}{br}{i:03d}'],errors='coerce')
def hsgap(df,pre,brs,ncat,starts):
    out={}
    for r,br in brs.items():
        tot=sum(col(df,pre,br,s0+j) for s0 in starts for j in range(ncat)); lo=sum(col(df,pre,br,s0+j) for s0 in starts for j in range(2))
        out[r]=(1-lo/tot.where(tot>0)); out['n_'+r]=tot
    return out
res=[]
# 1990: 6 cats; male block starts 1,7,13,19,25,31,37,43 ; female +48
a=rd('ds125_1990'); B90={'w':'AAA','b':'AAB'}
groups90={'25-34 (born 1956-65)':[7],'35-44 (born 1946-55)':[13],'45-54 (born 1936-45)':[19],'55-64 (born 1926-35)':[25,31],'65+ (born before 1926)':[37,43]}
for lab,ms in groups90.items():
    o=hsgap(a,'FF6',B90,6,ms+[m+48 for m in ms]); d=pd.DataFrame({'GISJOIN':a.GISJOIN,'gap':o['w']-o['b'],'nb':o['n_b']}); d=d[d.nb>=30]
    r=run('1990 age '+lab,d[['GISJOIN','gap']].dropna(),2020,'gap'); res.append(r)
a=rd('ds153_2000'); B00={'w':'AAAA','b':'AAAC'}
groups00={'25-34 (born 1966-75)':[8],'35-44 (born 1956-65)':[15],'45-64 (born 1936-55)':[22],'65+ (born before 1936)':[29]}
for lab,ms in groups00.items():
    o=hsgap(a,'HYC',B00,7,ms+[m+35 for m in ms]); d=pd.DataFrame({'GISJOIN':a.GISJOIN,'gap':o['w']-o['b'],'nb':o['n_b']}); d=d[d.nb>=30]
    r=run('2000 age '+lab,d[['GISJOIN','gap']].dropna(),2020,'gap'); res.append(r)
r=pd.DataFrame(res)[['outcome','n','beta_cotton','t_cotton','noise95_cotton']]; print(r.to_string(index=False)); r.to_csv('hs_cohort_results.csv',index=False)
