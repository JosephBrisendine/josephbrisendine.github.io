import pandas as pd, numpy as np
w=pd.read_csv('seer_county_race.csv',dtype={'stf':str,'cty':str,'GISJOIN':str})
c=pd.read_csv('S1860_on_2020.csv',dtype={'GISJOIN':str})
FIPS={'01','05','10','12','13','21','22','24','28','29','37','45','47','48','51','54'}
c=c[(c.cover>=0.9)&c.S20.notna()]
d=w[w.stf.isin(FIPS)].merge(c[['GISJOIN','S20']],on='GISJOIN')
yrs=sorted(d.year.unique()); n_by=d.groupby('GISJOIN').year.nunique(); d=d[d.GISJOIN.isin(n_by[n_by==len(yrs)].index)]
print('counties in balanced annual panel:',d.GISJOIN.nunique())
def wdemean(x,g,wt): return x-(x*wt).groupby(g).transform('sum')/wt.groupby(g).transform('sum')
rows=[]
for y,g in d.groupby('year'):
    one=pd.Series(1.0,index=g.index); pw=g.tot.astype(float)
    Sd=wdemean(g.S20,g.stf,one); Yd=wdemean(g.bshare,g.stf,one)
    b=(Yd*Sd).sum()/(Sd*Sd).sum(); m=g.bshare.mean()
    Ly=np.log(g.bshare.clip(lower=0.005)); Ld=wdemean(Ly,g.stf,one); bl=(Ld*Sd).sum()/(Sd*Sd).sum()
    Sdw=wdemean(g.S20,g.stf,pw); Ydw=wdemean(g.bshare,g.stf,pw); bw=(pw*Ydw*Sdw).sum()/(pw*Sdw*Sdw).sum(); mw=(pw*g.bshare).sum()/pw.sum()
    rows.append(dict(year=y,beta=b,mean=m,beta_rel=b/m,beta_log=bl,beta_popw=bw,mean_popw=mw,beta_rel_popw=bw/mw,corr=np.corrcoef(Yd,Sd)[0,1]))
o=pd.DataFrame(rows); o.to_csv('seer_beta_annual.csv',index=False)
print(o[o.year%5==0].round(3).to_string(index=False))
# trend shape tests per series: slope per decade by era, and quadratic curvature 1990-2024
for col in ['beta','beta_rel','beta_log','beta_popw','beta_rel_popw']:
    s=o.set_index('year')[col]
    sl={f'{a}-{b}':round((s[b]-s[a])/(b-a)*10,3) for a,b in [(1970,1980),(1980,1990),(1990,2000),(2000,2010),(2010,2020),(2015,2024)]}
    t=np.arange(1990,2025); y=s.loc[1990:2024].values; q=np.polyfit(t-2007,y,2)
    print(f'{col:15s} change per decade {sl}  quad curvature(1990-2024)={q[0]*100:.4f} per decade^2')
