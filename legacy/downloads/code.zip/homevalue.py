import pandas as pd, numpy as np, geopandas as gpd, glob
rng=np.random.default_rng(6)
SS=['Alabama','Arkansas','Delaware','Florida','Georgia','Kentucky','Louisiana','Maryland','Mississippi','Missouri','North Carolina','South Carolina','Tennessee','Texas','Virginia','West Virginia']
FIPS={'01':'Alabama','05':'Arkansas','10':'Delaware','12':'Florida','13':'Georgia','21':'Kentucky','22':'Louisiana','24':'Maryland','28':'Mississippi','29':'Missouri','37':'North Carolina','45':'South Carolina','47':'Tennessee','48':'Texas','51':'Virginia','54':'West Virginia'}
def base(y):
    if y==2020:
        b=pd.read_csv('S1860_on_2020.csv',dtype={'GISJOIN':str}).rename(columns={'S20':'S'})
        g=gpd.read_file('shp/US_county_2020.shp',columns=['GISJOIN','STATEFP']); g['cx']=g.geometry.centroid.x/1000; g['cy']=g.geometry.centroid.y/1000
        b=b.merge(g.drop(columns='geometry'),on='GISJOIN'); b['STATE']=b.STATEFP.map(FIPS)
    else: b=pd.read_csv(f'S1860_on_{y}.csv',dtype={'GISJOIN':str})
    b=b.merge(pd.read_csv(f'cotton_{y}.csv',dtype={'GISJOIN':str}),on='GISJOIN')
    b=b[b.STATE.isin(SS)&(b.cover>=0.9)&b.S.notna()&b.cotton.notna()].reset_index(drop=True)
    b['cz']=(b.cotton-b.cotton.mean())/b.cotton.std()
    D=np.sqrt((b.cx.values[:,None]-b.cx.values[None])**2+(b.cy.values[:,None]-b.cy.values[None])**2)
    N=np.linalg.cholesky(np.exp(-D/180)+1e-6*np.eye(len(D)))@rng.standard_normal((len(D),300))
    return b,N,dict(zip(b.GISJOIN,range(len(b))))
B={2020:base(2020)}
for y,(b,_,_) in B.items():
    r=np.corrcoef(b.S,b.cotton)[0,1]; print(f'{y}: n={len(b)} corr(S,cotton)={r:.2f}')
def reg(v,Z,y,w=None):
    w=np.ones(len(y)) if w is None else w; sw=np.sqrt(w)
    X=np.column_stack([v,Z])*sw[:,None]; yy=y*sw; bb=np.linalg.lstsq(X,yy,rcond=None)[0]; r=yy-X@bb
    return bb[0], bb[0]/np.sqrt(r@r/(len(y)-X.shape[1])*np.linalg.pinv(X.T@X)[0,0])
def run(name,d,by,ycol,w=None,fe='STATE'):
    b,N,idx=B[by]; d=d.merge(b[['GISJOIN','STATE','S','cz']],on='GISJOIN',suffixes=('_x','')); ii=d.GISJOIN.map(idx).values
    fe_=pd.get_dummies(d[fe].astype(str),drop_first=True).values.astype(float); one=np.ones(len(d)); yv=d[ycol].values; ww=None if w is None else d[w].values.astype(float)
    out={'outcome':name,'n':len(d)}
    for lab,Z in [('no_cotton',np.column_stack([one,fe_])),('cotton',np.column_stack([one,fe_,d.cz,d.cz**2]))]:
        be,t=reg(d.S.values,Z,yv,ww); tn=np.array([reg(N[ii,k],Z,yv,ww)[1] for k in range(300)])
        out[f'beta_{lab}']=round(be,3); out[f't_{lab}']=round(t,1); out[f'noise95_{lab}']=round(np.quantile(abs(tn),.95),1)
    out['kept_%']=round(100*out['beta_cotton']/out['beta_no_cotton']); return out

a=pd.read_csv('raw16/nhgis0016_csv/nhgis0016_ds262_20225_county.csv',encoding='latin-1',dtype={'GISJOIN':str},low_memory=False)
f=lambda c: pd.to_numeric(a[c],errors='coerce')
d=pd.DataFrame({'GISJOIN':a.GISJOIN,'vw':f('AQU5E001'),'vb':f('AQU6E001'),'mb':f('AQU6M001')})
d=d[(d.vb>0)&(d.vw>0)&(d.mb/d.vb<0.5)]
t=pd.read_csv('raw9/nhgis0009_csv/nhgis0009_ts_nominal_county.csv',encoding='latin-1',dtype={'GISJOIN':str})
g=lambda c: pd.to_numeric(t[c],errors='coerce')
h=pd.DataFrame({'GISJOIN':t.GISJOIN,'hb':g('B39AB2020')/(g('B39AB2020')+g('B39AF2020')),'hw':g('B39AA2020')/(g('B39AA2020')+g('B39AE2020')),'nb':g('B39AB2020')+g('B39AF2020')})
d=d.merge(h,on='GISJOIN'); d=d[d.nb>=50]
d['log_vb']=np.log(d.vb); d['log_val_ratio']=np.log(d.vb/d.vw)
d['log_wealth_b']=np.log(d.hb*d.vb); d['log_wealth_ratio']=np.log((d.hb*d.vb)/(d.hw*d.vw))
d['home_b']=d.hb; d['home_gap']=d.hw-d.hb
res=[]
for col in ['home_b','home_gap','log_vb','log_val_ratio','log_wealth_b','log_wealth_ratio']:
    r=run(col,d[['GISJOIN',col]].dropna(),2020,col); r['mean']=round(d[col].mean(),3); res.append(r)
r=pd.DataFrame(res); print('counties:',len(d)); print(r.drop(columns=['noise95_no_cotton']).to_string(index=False))
print('median Black value $',d.vb.median(),' white $',d.vw.median(),' median ratio',round((d.vb/d.vw).median(),2))
r.to_csv('homevalue_results.csv',index=False)
