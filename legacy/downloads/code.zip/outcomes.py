import pandas as pd, numpy as np, glob
D4='raw4/nhgis0004_csv/nhgis0004_'
def rd(k): return pd.read_csv(f'{D4}{k}_county.csv',encoding='latin-1',dtype={'GISJOIN':str},low_memory=False)
out=[]
def add(name,year,df,num,den,wcol=None):
    d=pd.DataFrame({'GISJOIN':df.GISJOIN,'outcome':name,'year':year})
    n=df[num].sum(axis=1); m=df[den].sum(axis=1)
    d['y']=n/m.where(m>0); d['w']=m; out.append(d)
# Black farm ownership share (owners incl part owners / all Black-operated farms)
a=rd('ds31_1900'); add('black_own',1900,a,['AZO007','AZO008','AZO009'],['AZN002']); add('white_own',1900,a,['AZO001','AZO002','AZO003'],['AZN001'])
a=rd('ds37_1910'); add('black_own',1910,a,['A42003'],['A4U003']); add('white_own',1910,a,['A42001'],['A4U001'])
a=rd('ds210_1920'); add('black_own',1920,a,['AB38003'],['AB3R004']); add('white_own',1920,a,['AB38001'],['AB3R002'])
a=rd('ds212_1930'); add('black_own',1930,a,['AB96011','AB96012'],['AB96010']); add('white_own',1930,a,['AB96003','AB96004'],['AB96002'])
# adult male illiteracy (Black)
a=rd('ds31_1900'); add('black_illit_m21',1900,a,['AYN004'],['AYN003','AYN004'])
a=rd('ds37_1910'); add('black_illit_m21',1910,a,['A35003'],['A32005'])
a=rd('ds43_1920'); add('black_illit_m21',1920,a,['A70003'],['A7P004'])
# infant mortality, nonwhite and white, per birth
for f in sorted(glob.glob(D4+'ds224_*_county.csv')):
    yr=int(f.split('_')[-2]); a=pd.read_csv(f,encoding='latin-1',dtype={'GISJOIN':str})
    b=[c for c in a.columns if c.endswith('V002') and c.startswith('AF')]; i=[c for c in a.columns if c.startswith('AF') and c[:4]==b[0][:2]+'11']
    # locate columns by codebook order: births table T1, infant deaths T4
    cb=open(f.replace('_county.csv','_county_codebook.txt'),encoding='latin-1').read()
    import re
    births=re.search(r'(\w+)002:\s+Births: Non-white',cb).group(1); inf=re.search(r'(\w+)002:\s+Infant deaths \(under 1 year\): Non-white',cb).group(1)
    for c in [births+'001',births+'002',inf+'001',inf+'002']: a[c]=pd.to_numeric(a[c],errors='coerce')
    add('black_imr',yr,a,[inf+'002'],[births+'002']); add('white_imr',yr,a,[inf+'001'],[births+'001'])
o=pd.concat(out); o.to_csv('outcomes_long.csv',index=False)
s=pd.read_csv('s1860_nominal.csv',dtype={'GISJOIN':str})
SS=['Alabama','Arkansas','Delaware','Florida','Georgia','Kentucky','Louisiana','Maryland','Mississippi','Missouri','North Carolina','South Carolina','Tennessee','Texas','Virginia']
m=o.merge(s[s.STATE.isin(SS)][['GISJOIN','STATE','S']],on='GISJOIN')
print(m.groupby(['outcome','year']).agg(n=('y','count'),mean=('y','mean'),w=('w','median')).round(3).to_string())
