import pandas as pd, numpy as np, geopandas as gpd
g=gpd.read_file('shp/US_county_2020.shp')[['GISJOIN','STATEFP']]
FIPS=['01','05','10','12','13','21','22','24','28','29','37','45','47','48','51','54']
P=pd.read_csv('panel2020.csv',dtype={'GISJOIN':str})
st=set(pd.read_csv('stable_counties.csv').GISJOIN)
Y=[1870,1880,1890,1900,1910,1920,1930,1940,1950,1960,1970,1980,1990,2000,2010,2020]
b=g[g.STATEFP.isin(FIPS)&g.GISJOIN.isin(st)].merge(pd.read_csv('S1860_on_2020.csv',dtype={'GISJOIN':str})[['GISJOIN','S20']],on='GISJOIN').merge(pd.read_csv('cotton_2020.csv',dtype={'GISJOIN':str}),on='GISJOIN')
b=b.merge(P[P.year==1860][['GISJOIN','logdens']].rename(columns={'logdens':'ld60'}),on='GISJOIN').merge(P[P.year.isin(Y)].pivot(index='GISJOIN',columns='year',values='bshare'),left_on='GISJOIN',right_index=True).dropna().reset_index(drop=True)
b['cz']=(b.cotton-b.cotton.mean())/b.cotton.std(); fe=pd.get_dummies(b.STATEFP,drop_first=True).values.astype(float)
Z=np.column_stack([np.ones(len(b)),fe,b.cz,b.cz**2,b.ld60])
rows=[]
for y in Y:
    c=np.linalg.lstsq(np.column_stack([b.S20,Z]),b[y].values,rcond=None)[0]; rows.append((y,c[0]/b[y].mean()))
s=pd.DataFrame(rows,columns=['year','rel']); s['surv']=s.rel/s.rel.iloc[0]; s['lag']=s.year-1870; s['curve']='slavery map'
a=pd.read_csv('age_spectrum_stable.csv'); a=a[a.t!=2024]
r=a[a.t0==1870][['lag','s_amp']].rename(columns={'s_amp':'surv'}); r['curve']='1865-70 resettlement'
f=pd.read_csv('flood_results.csv'); f=f[(f.treat=='flood')&(f.outcome=='bshare')&(f.year>=1930)&(f.year<=2020)].copy()
f['surv']=f.beta/f.beta.iloc[0]; f['lag']=f.year-1930; f['curve']='1927 flood'
out=pd.concat([s[['curve','lag','surv']],r,f[['curve','lag','surv']]]); out.to_csv('three_memories.csv',index=False)
print(out.round(2).pivot(index='lag',columns='curve',values='surv').to_string()); print('stable n',len(b))
