import pandas as pd, numpy as np, geopandas as gpd, glob
rng=np.random.default_rng(6)
SS=['Alabama','Arkansas','Delaware','Florida','Georgia','Kentucky','Louisiana','Maryland','Mississippi','Missouri','North Carolina','South Carolina','Tennessee','Texas','Virginia','West Virginia']
FIPS={'01':'Alabama','05':'Arkansas','10':'Delaware','12':'Florida','13':'Georgia','21':'Kentucky','22':'Louisiana','24':'Maryland','28':'Mississippi','29':'Missouri','37':'North Carolina','45':'South Carolina','47':'Tennessee','48':'Texas','51':'Virginia','54':'West Virginia'}
def base(y):
    if y==2020:
        b=pd.read_csv('S1860_on_2020.csv',dtype={'GISJOIN':str}).rename(columns={'S20':'S'})
        g=gpd.read_file('shp/US_county_2020.shp',columns=['GISJOIN','STATEFP']); g['cx']=g.geometry.centroid.x/1000; g['cy']=g.geometry.centroid.y/1000
        b=b.merge(g.drop(columns='geometry'),on='GISJOIN'); b['STATE']=b.STATEFP.map(FIPS)
    else: b=pd.read_csv(f'S1860_on_{y}.csv',dtype={'GISJOIN':str})
    b=b.merge(pd.read_csv(f'cotton_{y}.csv',dtype={'GISJOIN':str}),on='GISJOIN')
    b=b[b.STATE.isin(SS)&(b.cover>=0.9)&b.S.notna()&b.cotton.notna()].reset_index(drop=True)
    b['cz']=(b.cotton-b.cotton.mean())/b.cotton.std()
    D=np.sqrt((b.cx.values[:,None]-b.cx.values[None])**2+(b.cy.values[:,None]-b.cy.values[None])**2)
    N=np.linalg.cholesky(np.exp(-D/180)+1e-6*np.eye(len(D)))@rng.standard_normal((len(D),300))
    return b,N,dict(zip(b.GISJOIN,range(len(b))))
B={2020:base(2020)}
for y,(b,_,_) in B.items():
    r=np.corrcoef(b.S,b.cotton)[0,1]; print(f'{y}: n={len(b)} corr(S,cotton)={r:.2f}')
def reg(v,Z,y,w=None):
    w=np.ones(len(y)) if w is None else w; sw=np.sqrt(w)
    X=np.column_stack([v,Z])*sw[:,None]; yy=y*sw; bb=np.linalg.lstsq(X,yy,rcond=None)[0]; r=yy-X@bb
    return bb[0], bb[0]/np.sqrt(r@r/(len(y)-X.shape[1])*np.linalg.pinv(X.T@X)[0,0])
def run(name,d,by,ycol,w=None,fe='STATE'):
    b,N,idx=B[by]; d=d.merge(b[['GISJOIN','STATE','S','cz']],on='GISJOIN',suffixes=('_x','')); ii=d.GISJOIN.map(idx).values
    fe_=pd.get_dummies(d[fe].astype(str),drop_first=True).values.astype(float); one=np.ones(len(d)); yv=d[ycol].values; ww=None if w is None else d[w].values.astype(float)
    out={'outcome':name,'n':len(d)}
    for lab,Z in [('no_cotton',np.column_stack([one,fe_])),('cotton',np.column_stack([one,fe_,d.cz,d.cz**2]))]:
        be,t=reg(d.S.values,Z,yv,ww); tn=np.array([reg(N[ii,k],Z,yv,ww)[1] for k in range(300)])
        out[f'beta_{lab}']=round(be,3); out[f't_{lab}']=round(t,1); out[f'noise95_{lab}']=round(np.quantile(abs(tn),.95),1)
    out['kept_%']=round(100*out['beta_cotton']/out['beta_no_cotton']); return out

P='raw13/nhgis0013_csv/nhgis0013_'
ts=pd.read_csv(P+'ts_nominal_county.csv',encoding='latin-1',dtype={'GISJOIN':str})
res=[]; rows=[]
for k,w,b,p in [('ds206_20145','ABFTE001','ABFUE001','145'),('ds239_20185','AJ0PE001','AJ0QE001','185'),('ds249_20205','AMTNE001','AMTOE001','205')]:
    a=pd.read_csv(P+k+'_county.csv',encoding='latin-1',dtype={'GISJOIN':str},low_memory=False)[['GISJOIN',w,b]].merge(ts[['GISJOIN','B18AA'+p,'B18AB'+p]],on='GISJOIN')
    a=a.apply(lambda c: pd.to_numeric(c,errors='coerce') if c.name!='GISJOIN' else c)
    a['pci_w']=a[w]/a['B18AA'+p]; a['pci_b']=a[b]/a['B18AB'+p]; a=a[(a['B18AB'+p]>=500)&(a.pci_b>0)&(a.pci_w>0)]
    a['log_pci_b']=np.log(a.pci_b); a['log_ratio']=np.log(a.pci_b/a.pci_w)
    lab='20'+p[:2]
    for col in ['log_pci_b','log_ratio']:
        r=run(f'{col} {k[-5:-1]}',a[['GISJOIN',col]].dropna(),2020,col); r['mean']=round(a[col].mean(),3); res.append(r)
    print(k, 'median Black/white per-capita income ratio:', round((a.pci_b/a.pci_w).median(),2), ' n=',len(a))
r=pd.DataFrame(res); print(r.drop(columns=['noise95_no_cotton']).to_string(index=False)); r.to_csv('income_results.csv',index=False)
