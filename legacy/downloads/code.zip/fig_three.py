import pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
m=pd.read_csv('three_memories.csv'); a=pd.read_csv('age_spectrum_stable.csv'); a=a[(a.t!=2024)&(a.t0>1870)]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11})
fig,ax=plt.subplots(figsize=(10,6),dpi=150,facecolor='#fcfcfb'); ax.set_facecolor('#fcfcfb')
for t0,d in a.groupby('t0'): ax.plot(d.lag,d.s_amp,color='#cfd3d8',lw=1.1,zorder=1)
ax.axhline(1,color='#898781',lw=1,ls=(0,(4,3)),zorder=2); ax.axhline(0,color='#52514e',lw=1,zorder=2)
C={'1865-70 resettlement':'#c0392b','slavery map':'#2a78d6','1927 flood':'#b8860b'}
LAB={'1865-70 resettlement':'Where freedpeople settled, 1865–70:\nkept almost whole','slavery map':'The 1860 slavery map:\nheld a century, now eroding','1927 flood':'The 1927 flood:\nforgotten, then reversed'}
for c,d in m.groupby('curve'):
    d=d.sort_values('lag'); ax.plot(d.lag,d.surv,color=C[c],lw=3,zorder=3,solid_capstyle='round'); ax.plot(d.lag.iloc[-1],d.surv.iloc[-1],'o',color=C[c],ms=6,zorder=4)
    e=d.iloc[-1]; ax.text(e.lag+3,e.surv,LAB[c],va='center',fontsize=10,color='#14171a')
ax.text(46,2.35,'Gray: every later decade’s new piece of the map',fontsize=9.5,color='#6b7178')
ax.set_xlabel('Years since the pattern was set'); ax.set_ylabel('Share of it still present\n(1 = all of it, 0 = none, below 0 = reversed)')
fig.text(0.07,0.955,'Three ways a place remembers',fontsize=14,color='#14171a',weight='bold')
fig.text(0.07,0.905,'How much of each pattern in Southern counties’ Black population share survives, years later. Census data,\n606 counties with unchanged boundaries (flood: 549 Delta-region counties). Same controls and noise tests throughout.',fontsize=9.5,color='#4f555c')
for s in ['top','right']: ax.spines[s].set_visible(False)
for s in ['left','bottom']: ax.spines[s].set_color('#c9ccd0')
ax.grid(axis='y',color='#eceef0',lw=.8,zorder=0); ax.set_xlim(0,205); ax.set_ylim(-1.75,2.7); ax.set_xticks(range(0,160,20))
fig.tight_layout(rect=(0,0,1,0.86)); fig.savefig('site/three_memories.png',facecolor='#fcfcfb'); print('ok')
