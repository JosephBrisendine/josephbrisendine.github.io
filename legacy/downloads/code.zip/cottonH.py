import geopandas as gpd, pandas as pd, numpy as np
from rasterstats import zonal_stats
TIF='/mnt/user-data/uploads/fcd325aa-cott200a_yld-2.tif'
for y,f in [(1860,'shp/US_county_1860_conflated.shp'),(1900,'shp/US_county_1900_conflated.shp'),(1930,'shp/US_county_1930_conflated.shp'),(2020,'shp/US_county_2020.shp')]:
    g=gpd.read_file(f,columns=['GISJOIN']).to_crs(4326)
    zs=zonal_stats(g,TIF,stats=['mean'],nodata=-9,all_touched=True)
    g['cotton']=[z['mean'] for z in zs]; g[['GISJOIN','cotton']].to_csv(f'cottonH_{y}.csv',index=False)
    print(y,g.cotton.describe().round(1).to_dict())
