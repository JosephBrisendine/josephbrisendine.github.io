import pandas as pd, numpy as np, geopandas as gpd, re
o=pd.read_csv('/home/claude/dl/logan/ICPSR_115861-V1.1/Officials_Raw_JEH_12-30-19.csv',encoding='latin-1')
AB={'SC':'South Carolina','MS':'Mississippi','LA':'Louisiana','NC':'North Carolina','AL':'Alabama','GA':'Georgia','VA':'Virginia','FL':'Florida','AR':'Arkansas','TX':'Texas','TN':'Tennessee'}
def key(s): return re.sub(r'[^A-Z]','',str(s).upper().replace('SAINT','ST').replace('PARISH','').replace('COUNTY',''))
FIX={('Alabama','BULLOCK'):'MACON',('Alabama','CLAY'):'TALLADEGA',('Alabama','ELMORE'):'AUTAUGA',('Alabama','HALE'):'GREENE',('Alabama','LEE'):'RUSSELL',
('Arkansas','LEE'):'PHILLIPS',('Arkansas','WOODRUFF'):'JACKSON',('Louisiana','EASTCARROLL'):'CARROLL',('Louisiana','EBATONROUGE'):'EASTBATONROUGE',
('Louisiana','WBATONROUGE'):'WESTBATONROUGE',('Louisiana','GRANT'):'RAPIDES',('Louisiana','IBERIA'):'STMARTIN',('Louisiana','STJOHNBAPTIST'):'STJOHNTHEBAPTIST',
('Louisiana','TERREBONE'):'TERREBONNE',('Mississippi','CLAY'):'LOWNDES',('Mississippi','GRENADA'):'YALOBUSHA',('North Carolina','VANCE'):'GRANVILLE',
('South Carolina','AIKEN'):'EDGEFIELD',('South Carolina','BERKELEY'):'CHARLESTON',('South Carolina','DORCHESTER'):'COLLETON',('South Carolina','FLORENCE'):'DARLINGTON',
('Virginia','ALEXANDRIACITY'):'ALEXANDRIA',('Virginia','HAMPTONCITY'):'ELIZABETHCITY',('Virginia','NORFOLKCITY'):'NORFOLK',('Virginia','PETERSBURGCITY'):'DINWIDDIE',('Virginia','VIRGINIABEACHCITY'):'PRINCESSANNE'}
rows=[]
for _,r in o.iterrows():
    for sc,cc in [('State of Office','County of Office'),('State of Office 2','County of Office 2')]:
        if r[sc] in AB and isinstance(r[cc],str): st=AB[r[sc]]; k=key(r[cc]); rows.append((r.ID,st,FIX.get((st,k),k)))
c=pd.DataFrame(rows,columns=['ID','st','k']).drop_duplicates().groupby(['st','k']).ID.nunique().rename('n_off').reset_index()
g=gpd.read_file('shp/US_county_1860_conflated.shp')
g=g[g.STATENAM.isin(AB.values())].copy(); g['k']=g.NHGISNAM.map(key)
m=g.merge(c,left_on=['STATENAM','k'],right_on=['st','k'],how='left')
un=c.merge(g[['STATENAM','k']],left_on=['st','k'],right_on=['STATENAM','k'],how='left',indicator=True); un=un[un._merge=='left_only']
print('officials-counties',len(c),'matched',len(c)-len(un),'| unmatched officials',un.n_off.sum(),'of',c.n_off.sum()); print(un[['st','k','n_off']].to_string(index=False))
m['n_off']=m.n_off.fillna(0); m['any_off']=(m.n_off>0).astype(float); m['ln_off']=np.log1p(m.n_off)
print('1860 counties with any official:',int(m.any_off.sum()),'of',len(m))
m=m[['GISJOIN','STATENAM','n_off','any_off','ln_off','geometry']]
m.drop(columns='geometry').to_csv('logan_1860.csv',index=False)
def onto(target,keycol='GISJOIN'):
    t=gpd.read_file(f'shp/{target}.shp')[[keycol,'geometry']].to_crs(m.crs); t['at']=t.area
    x=gpd.overlay(m[['any_off','ln_off','geometry']],t,how='intersection',keep_geom_type=True); x['ia']=x.area
    a=x.groupby(keycol).apply(lambda d: pd.Series({'any_off':np.average(d.any_off,weights=d.ia),'ln_off':np.average(d.ln_off,weights=d.ia),'cov':d.ia.sum()}),include_groups=False).reset_index()
    a=a.merge(t[[keycol,'at']],on=keycol); a['cov']=a['cov']/a['at']; return a.drop(columns='at')
for nm in ['US_county_1900_conflated','US_county_1930_conflated','US_county_2020']:
    a=onto(nm); a.to_csv(f'logan_on_{nm.split("_")[2]}.csv',index=False); print(nm,len(a),round(a.any_off.mean(),3))
