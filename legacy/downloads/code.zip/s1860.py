import pandas as pd
U='/mnt/user-data/uploads/'
ts=pd.read_csv(U+'ded75e4e-nhgis0001_ts_nominal_county.csv',dtype=str,encoding='latin-1')
print(ts.columns.tolist()); print(ts.YEAR.value_counts().sort_index().to_dict())
t60=ts[ts.YEAR=='1860'][['GISJOIN','STATE','NAME','A00AA']].copy()
t60['tot']=pd.to_numeric(t60.A00AA)
free=pd.read_csv(U+'ccd35c81-nhgis0001_ds14_1860_county.csv',dtype={'GISJOIN':str},encoding='latin-1')
m=free[['GISJOIN','STATE','COUNTY','AH7001']].merge(t60[['GISJOIN','tot']],on='GISJOIN',how='outer',indicator=True)
print(m._merge.value_counts())
m['enslaved']=m.tot-m.AH7001; m['S']=m.enslaved/m.tot
print('US enslaved total:',m.enslaved.sum(), ' negatives:',(m.enslaved<0).sum())
print(m.groupby('STATE').enslaved.sum().sort_values(ascending=False).head(16))
print(m[(m.STATE=='Georgia')&m.COUNTY.isin(['Mitchell','Dougherty','Baker','Fulton','Cobb'])])
# compare 1850 slaves
s50=pd.read_csv(U+'61e1ef99-nhgis0001_ds10_1850_county.csv'); print('1850 slaves',s50.AE6003.sum())
# race TS years with data
b=ts[ts.B18AB.notna()&(ts.B18AB!='')]; print('B18 years',sorted(b.YEAR.unique()))
m.to_csv('s1860_nominal.csv',index=False)
