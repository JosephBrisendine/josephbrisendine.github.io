import pandas as pd, numpy as np, geopandas as gpd, sys
rng=np.random.default_rng(12)
g20=gpd.read_file('shp/US_county_2020.shp')[['GISJOIN','STATEFP','geometry']]
g20['cx']=g20.centroid.x/1000; g20['cy']=g20.centroid.y/1000
P=pd.read_csv('panel2020.csv',dtype={'GISJOIN':str}); F=pd.read_csv('farmval2020.csv',dtype={'GISJOIN':str})
L=pd.concat([P[['GISJOIN','year','bshare']].rename(columns={'bshare':'y'}).assign(out='bshare'),
             P[['GISJOIN','year','logdens']].rename(columns={'logdens':'y'}).assign(out='logdens'),
             F.rename(columns={'lfv':'y'}).assign(out='lfv')])
YRS={'bshare':[1870,1880,1890,1900,1910,1920,1930,1940,1950,1960,1970,1980,1990,2000,2010,2020,2024],
     'logdens':[1870,1880,1890,1900,1910,1920,1930,1940,1950,1960,1970,1980,1990,2000,2010,2020,2024],
     'lfv':[1850,1870,1880,1890,1900,1910,1920,1925,1930,1935,1940,1945,1950,1954,1959]}
def reg(v,Z,y):
    X=np.column_stack([v,Z]); bb=np.linalg.lstsq(X,y,rcond=None)[0]; r=y-X@bb
    return bb[0], bb[0]/np.sqrt(r@r/(len(y)-X.shape[1])*np.linalg.pinv(X.T@X)[0,0])
def run(name,T,treats,states,mask=None):
    b=g20[g20.STATEFP.isin(states)].drop(columns='geometry').merge(T,on='GISJOIN')
    if mask is not None: b=b[b.GISJOIN.isin(mask)]
    b=b.merge(pd.read_csv('S1860_on_2020.csv',dtype={'GISJOIN':str})[['GISJOIN','S20']],on='GISJOIN').merge(pd.read_csv('cotton_2020.csv',dtype={'GISJOIN':str}),on='GISJOIN')
    b=b.merge(P[P.year==1860][['GISJOIN','logdens']].rename(columns={'logdens':'ld60'}),on='GISJOIN').merge(F[F.year==1860][['GISJOIN','lfv']].rename(columns={'lfv':'lfv60'}),on='GISJOIN')
    b=b.dropna(subset=['S20','cotton','ld60','lfv60']).reset_index(drop=True); b['cz']=(b.cotton-b.cotton.mean())/b.cotton.std()
    D=np.sqrt((b.cx.values[:,None]-b.cx.values[None])**2+(b.cy.values[:,None]-b.cy.values[None])**2)
    N=np.linalg.cholesky(np.exp(-D/180)+1e-6*np.eye(len(b)))@rng.standard_normal((len(b),300)); idx=dict(zip(b.GISJOIN,range(len(b))))
    fe=pd.get_dummies(b.STATEFP,drop_first=True).values.astype(float); res=[]
    for tr in treats:
        for out,yrs in YRS.items():
            for y in yrs:
                d=b.merge(L[(L.out==out)&(L.year==y)][['GISJOIN','y']],on='GISJOIN').dropna(subset=['y']); ii=d.GISJOIN.map(idx).values
                Z=np.column_stack([np.ones(len(d)),fe[ii],d.S20,d.cz,d.cz**2,d.ld60,d.lfv60])
                be,t=reg(d[tr].values,Z,d.y.values); tn=np.array([reg(N[ii,k],Z,d.y.values)[1] for k in range(300)])
                res.append(dict(contingency=name,treat=tr,outcome=out,year=y,n=len(d),beta=be,t=t,noise95=np.quantile(abs(tn),.95)))
    print(name,'n=',len(b)); return pd.DataFrame(res)
out=[]
# Sherman: GA/SC/NC within 100 miles of lines
D='/home/claude/dl/sherman/138946-V1/data/input/march_lines/'
Lx=pd.concat([gpd.read_file(D+f'{n}.shp').to_crs(g20.crs) for n in ['14th Army','15th Army','17th Army','20th Army','Cavalry']]).geometry.union_all()
g=g20[g20.STATEFP.isin(['13','45','37'])].copy(); g['march']=(g.geometry.intersection(Lx.buffer(8047)).area/g.area>0).astype(float)
near=g[g.geometry.intersects(Lx.buffer(160934))].GISJOIN
out.append(run('Sherman 1864',g[['GISJOIN','march']],['march'],['13','45','37'],mask=set(near)))
# Reconstruction officeholders, 11 former Confederate states
T=pd.read_csv('logan_on_2020.csv',dtype={'GISJOIN':str}); T=T[T['cov']>=0.8]
out.append(run('Reconstruction officials 1867-77',T[['GISJOIN','any_off','ln_off']],['any_off','ln_off'],['01','05','12','13','22','28','37','45','47','48','51']))
r=pd.concat(out); r.to_csv('contingency_results.csv',index=False)
r['sig']=np.where(abs(r.t)>r.noise95,'*','')
for (c,tr),d in r.groupby(['contingency','treat']):
    print('\n###',c,tr); print(d.assign(cell=d.beta.round(3).astype(str)+' ('+d.t.round(1).astype(str)+'/'+d.noise95.round(1).astype(str)+')'+d.sig).pivot(index='year',columns='outcome',values='cell').to_string())
