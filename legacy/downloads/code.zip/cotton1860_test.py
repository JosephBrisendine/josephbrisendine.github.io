import pandas as pd, numpy as np, geopandas as gpd, glob
rng=np.random.default_rng(6)
SS=['Alabama','Arkansas','Delaware','Florida','Georgia','Kentucky','Louisiana','Maryland','Mississippi','Missouri','North Carolina','South Carolina','Tennessee','Texas','Virginia','West Virginia']
FIPS={'01':'Alabama','05':'Arkansas','10':'Delaware','12':'Florida','13':'Georgia','21':'Kentucky','22':'Louisiana','24':'Maryland','28':'Mississippi','29':'Missouri','37':'North Carolina','45':'South Carolina','47':'Tennessee','48':'Texas','51':'Virginia','54':'West Virginia'}
def base(y):
    if y==2020:
        b=pd.read_csv('S1860_on_2020.csv',dtype={'GISJOIN':str}).rename(columns={'S20':'S'})
        g=gpd.read_file('shp/US_county_2020.shp',columns=['GISJOIN','STATEFP']); g['cx']=g.geometry.centroid.x/1000; g['cy']=g.geometry.centroid.y/1000
        b=b.merge(g.drop(columns='geometry'),on='GISJOIN'); b['STATE']=b.STATEFP.map(FIPS)
    else: b=pd.read_csv(f'S1860_on_{y}.csv',dtype={'GISJOIN':str})
    b=b.merge(pd.read_csv(f'cotton_{y}.csv',dtype={'GISJOIN':str}),on='GISJOIN')
    b=b[b.STATE.isin(SS)&(b.cover>=0.9)&b.S.notna()&b.cotton.notna()].reset_index(drop=True)
    b['cz']=(b.cotton-b.cotton.mean())/b.cotton.std()
    b=b.merge(pd.read_csv(f'cotton1860_on_{y}.csv',dtype={'GISJOIN':str})[['GISJOIN','cot1860']],on='GISJOIN'); b=b[b.cot1860.notna()].reset_index(drop=True); b['c2']=(b.cot1860-b.cot1860.mean())/b.cot1860.std()
    D=np.sqrt((b.cx.values[:,None]-b.cx.values[None])**2+(b.cy.values[:,None]-b.cy.values[None])**2)
    N=np.linalg.cholesky(np.exp(-D/180)+1e-6*np.eye(len(D)))@rng.standard_normal((len(D),300))
    return b,N,dict(zip(b.GISJOIN,range(len(b))))

B={y:base(y) for y in [1900,1930,2020]}
for y,(b,_,_) in B.items(): print(y,'n',len(b),'corr(S,GAEZ)',round(np.corrcoef(b.S,b.cz)[0,1],2),'corr(S,cotton1860)',round(np.corrcoef(b.S,b.c2)[0,1],2))
def reg(v,Z,y,w=None):
    w=np.ones(len(y)) if w is None else w; sw=np.sqrt(w)
    X=np.column_stack([v,Z])*sw[:,None]; yy=y*sw; bb=np.linalg.lstsq(X,yy,rcond=None)[0]; r=yy-X@bb
    return bb[0], bb[0]/np.sqrt(r@r/(len(y)-X.shape[1])*np.linalg.pinv(X.T@X)[0,0])
def run4(name,d,by,ycol,w=None,fe='STATE'):
    b,N,idx=B[by]; d=d.merge(b[['GISJOIN','STATE','S','cz','c2']],on='GISJOIN',suffixes=('_x','')); ii=d.GISJOIN.map(idx).values
    F=pd.get_dummies(d[fe].astype(str),drop_first=True).values.astype(float); one=np.ones(len(d)); yv=d[ycol].values; ww=None if w is None else d[w].values.astype(float)
    out={'outcome':name,'n':len(d)}
    for lab,Z in [('none',[one,F]),('GAEZ',[one,F,d.cz,d.cz**2]),('cot1860',[one,F,d.c2,d.c2**2]),('both',[one,F,d.cz,d.cz**2,d.c2,d.c2**2])]:
        Z=np.column_stack(Z); be,t=reg(d.S.values,Z,yv,ww); tn=np.array([reg(N[ii,k],Z,yv,ww)[1] for k in range(150)])
        out[lab]=f"{be:+.3f} ({t:.1f}/{np.quantile(abs(tn),.95):.1f})"
    return out
res=[]
p=pd.read_csv('panel_nominal.csv',dtype={'GISJOIN':str})
res.append(run4('Black share 1900',p[p.YEAR==1900][['GISJOIN','bshare']].dropna(),1900,'bshare'))
ts=pd.read_csv(glob.glob('/mnt/user-data/uploads/*ts_nominal_county.csv')[0],encoding='latin-1',dtype=str); ts['bs']=pd.to_numeric(ts.B18AB)/pd.to_numeric(ts.A00AA)
res.append(run4('Black share 2020',ts[ts.YEAR=='2020'][['GISJOIN','bs']].dropna(),2020,'bs'))
o=pd.read_csv('outcomes_long.csv',dtype={'GISJOIN':str})
w=o.pivot_table(index=['GISJOIN','year'],columns='outcome',values='y').reset_index(); ww=o.pivot_table(index=['GISJOIN','year'],columns='outcome',values='w').reset_index()
w['own_gap']=w.white_own-w.black_own; w=w.merge(ww[['GISJOIN','year','black_own','black_illit_m21']].rename(columns={'black_own':'w_own','black_illit_m21':'w_il'}),on=['GISJOIN','year'])
for yr,by in [(1900,1900),(1920,1930),(1930,1930)]:
    d=w[(w.year==yr)&(w.w_own>=10)]; res.append(run4(f'White-Black farm ownership gap {yr}',d[['GISJOIN','own_gap']].dropna(),by,'own_gap'))
d=w[(w.year==1900)&(w.w_il>=50)]; res.append(run4('Black illiteracy 1900',d[['GISJOIN','black_illit_m21']].dropna(),1900,'black_illit_m21'))
m=pd.read_csv('modern_outcomes.csv',dtype={'GISJOIN':str})
for yr in [1980,2000]:
    d=m[(m.year==yr)&(m.n_b>=50)]; res.append(run4(f'High school gap {yr}',d[['GISJOIN','hs_gap']].dropna(),2020,'hs_gap'))
v=pd.read_csv('imr_1959_72.csv',dtype={'GISJOIN':str}); v['imr']=1000*v.dn/v.bn
OK=['Alabama','Delaware','Florida','Georgia','Louisiana','Maryland','Mississippi','North Carolina','South Carolina']
v=v.merge(B[2020][0][['GISJOIN','STATE']],on='GISJOIN'); v=v[v.STATE.isin(OK)&(v.bn>=50)&v.year.isin(range(1960,1966))]; v['sy']=v.STATE+v.year.astype(str)
res.append(run4('Black infant mortality 1960-65',v[['GISJOIN','imr','bn','sy']],2020,'imr',w='bn',fe='sy'))
a=pd.read_csv('raw16/nhgis0016_csv/nhgis0016_ds262_20225_county.csv',encoding='latin-1',dtype={'GISJOIN':str},low_memory=False)
hv=pd.DataFrame({'GISJOIN':a.GISJOIN,'vw':pd.to_numeric(a.AQU5E001,errors='coerce'),'vb':pd.to_numeric(a.AQU6E001,errors='coerce'),'mb':pd.to_numeric(a.AQU6M001,errors='coerce')})
hv=hv[(hv.vb>0)&(hv.vw>0)&(hv.mb/hv.vb<0.5)]; hv['lr']=np.log(hv.vb/hv.vw)
res.append(run4('Black/white home value 2018-22 (log)',hv[['GISJOIN','lr']],2020,'lr'))
at=pd.read_csv('/mnt/user-data/uploads/county_trends_estimates.csv',usecols=['state','county','kfr_black_pooled_p25_1978','kfr_white_pooled_p25_1978'])
at['GISJOIN']='G'+at.state.astype(str).str.zfill(2)+'0'+at.county.astype(str).str.zfill(3)+'0'; at['gap']=at.kfr_white_pooled_p25_1978-at.kfr_black_pooled_p25_1978
res.append(run4('Mobility gap, born 1978',at[['GISJOIN','gap']].dropna(),2020,'gap'))
r=pd.DataFrame(res); pd.set_option('display.width',250); print('cells: beta (t / noise 95%)'); print(r.to_string(index=False)); r.to_csv('cotton1860_results.csv',index=False)
