import geopandas as gpd, pandas as pd
g20=gpd.read_file('shp/US_county_2020.shp')[['GISJOIN','STATEFP','geometry']]
FIPS=['01','05','10','12','13','21','22','24','28','29','37','45','47','48','51','54']
g20=g20[g20.STATEFP.isin(FIPS)].rename(columns={'GISJOIN':'G20'}); g20['a20']=g20.area
keep=set(g20.G20)
for s in ['US_county_1860_conflated','US_county_1900_conflated','US_county_1930_conflated']:
    h=gpd.read_file(f'shp/{s}.shp')[['GISJOIN','geometry']].to_crs(g20.crs); h['ah']=h.area
    x=gpd.overlay(h,g20,how='intersection',keep_geom_type=True); x['ia']=x.area
    x['f20']=x.ia/x.a20; x['fh']=x.ia/x.ah
    ok=set(x[(x.f20>=0.95)&(x.fh>=0.95)].G20); keep&=ok; print(s,len(ok),'running',len(keep))
pd.Series(sorted(keep),name='GISJOIN').to_csv('stable_counties.csv',index=False)
