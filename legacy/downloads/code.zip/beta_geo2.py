import pandas as pd, numpy as np
rng=np.random.default_rng(5)
SS=['Alabama','Arkansas','Delaware','Florida','Georgia','Kentucky','Louisiana','Maryland','Mississippi','Missouri','North Carolina','South Carolina','Tennessee','Texas','Virginia','West Virginia']
bases={}
for y in [1900,1930]:
    b=pd.read_csv(f'S1860_on_{y}.csv',dtype={'GISJOIN':str}); b=b[b.STATE.isin(SS)&(b.cover>=0.9)&b.S.notna()].reset_index(drop=True)
    D=np.sqrt((b.cx.values[:,None]-b.cx.values[None])**2+(b.cy.values[:,None]-b.cy.values[None])**2)
    N=np.linalg.cholesky(np.exp(-D/180)+1e-6*np.eye(len(D)))@rng.standard_normal((len(D),400))
    bases[y]=(b,N,dict(zip(b.GISJOIN,range(len(b)))))
shape_for={1900:1900,1910:1900,1920:1930,1930:1930}
o=pd.read_csv('outcomes_long.csv',dtype={'GISJOIN':str})
w=o.pivot_table(index=['GISJOIN','year'],columns='outcome',values='y').reset_index()
ww=o.pivot_table(index=['GISJOIN','year'],columns='outcome',values='w').reset_index()
w['own_gap']=w.white_own-w.black_own
p=pd.read_csv('panel_nominal.csv',dtype={'GISJOIN':str})[['GISJOIN','YEAR','bshare']].rename(columns={'YEAR':'year','bshare':'black_share'})
w=w.merge(p,on=['GISJOIN','year'],how='outer')
mins={'black_share':0,'black_own':10,'own_gap':10,'black_illit_m21':50}
def reg(v,Z,y):
    X=np.column_stack([v,Z]); bb=np.linalg.lstsq(X,y,rcond=None)[0]; r=y-X@bb
    return bb[0], bb[0]/np.sqrt(r@r/(len(y)-X.shape[1])*np.linalg.pinv(X.T@X)[0,0])
old=pd.read_csv('beta_outcomes.csv').set_index(['outcome','year']); oldb=pd.read_csv('beta_t.csv'); oldb=oldb[~oldb.trend].set_index('year')
res=[]
for out,mn in mins.items():
  wk={'own_gap':'black_own'}.get(out,out)
  for yr,sy in shape_for.items():
    b,N,idx=bases[sy]
    d=w[w.year==yr][['GISJOIN',out]].dropna().merge(b[['GISJOIN','STATE','S']],on='GISJOIN')
    if mn: d=d.merge(ww[ww.year==yr][['GISJOIN',wk]].rename(columns={wk:'wt'}),on='GISJOIN'); d=d[d.wt>=mn]
    d=d[np.isfinite(d[out])]
    if len(d)<150: continue
    Z=np.column_stack([np.ones(len(d)),pd.get_dummies(d.STATE,drop_first=True).values.astype(float)]); ii=d.GISJOIN.map(idx).values
    be,t=reg(d.S.values,Z,d[out].values); tn=np.array([reg(N[ii,k],Z,d[out].values)[1] for k in range(400)])
    prev=oldb.beta.get(yr) if out=='black_share' else (old.beta.get((out,yr)) if (out,yr) in old.index else None)
    res.append(dict(outcome=out,year=yr,shapes=sy,n=len(d),beta=round(be,3),t=round(t,1),noise95=round(np.quantile(abs(tn),.95),1),beta_codematch=prev))
r=pd.DataFrame(res); print(r.to_string(index=False)); r.to_csv('beta_geo_hist.csv',index=False)
