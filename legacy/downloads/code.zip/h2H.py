import pandas as pd, numpy as np, geopandas as gpd, glob
rng=np.random.default_rng(6)
SS=['Alabama','Arkansas','Delaware','Florida','Georgia','Kentucky','Louisiana','Maryland','Mississippi','Missouri','North Carolina','South Carolina','Tennessee','Texas','Virginia','West Virginia']
FIPS={'01':'Alabama','05':'Arkansas','10':'Delaware','12':'Florida','13':'Georgia','21':'Kentucky','22':'Louisiana','24':'Maryland','28':'Mississippi','29':'Missouri','37':'North Carolina','45':'South Carolina','47':'Tennessee','48':'Texas','51':'Virginia','54':'West Virginia'}
def base(y):
    if y==2020:
        b=pd.read_csv('S1860_on_2020.csv',dtype={'GISJOIN':str}).rename(columns={'S20':'S'})
        g=gpd.read_file('shp/US_county_2020.shp',columns=['GISJOIN','STATEFP']); g['cx']=g.geometry.centroid.x/1000; g['cy']=g.geometry.centroid.y/1000
        b=b.merge(g.drop(columns='geometry'),on='GISJOIN'); b['STATE']=b.STATEFP.map(FIPS)
    else: b=pd.read_csv(f'S1860_on_{y}.csv',dtype={'GISJOIN':str})
    b=b.merge(pd.read_csv(f'cottonH_{y}.csv',dtype={'GISJOIN':str}),on='GISJOIN')
    b=b[b.STATE.isin(SS)&(b.cover>=0.9)&b.S.notna()&b.cotton.notna()].reset_index(drop=True)
    b['cz']=(b.cotton-b.cotton.mean())/b.cotton.std()
    D=np.sqrt((b.cx.values[:,None]-b.cx.values[None])**2+(b.cy.values[:,None]-b.cy.values[None])**2)
    N=np.linalg.cholesky(np.exp(-D/180)+1e-6*np.eye(len(D)))@rng.standard_normal((len(D),300))
    return b,N,dict(zip(b.GISJOIN,range(len(b))))
B={y:base(y) for y in [1900,1930,2020]}
for y,(b,_,_) in B.items():
    r=np.corrcoef(b.S,b.cotton)[0,1]; print(f'{y}: n={len(b)} corr(S,cotton)={r:.2f}')
def reg(v,Z,y,w=None):
    w=np.ones(len(y)) if w is None else w; sw=np.sqrt(w)
    X=np.column_stack([v,Z])*sw[:,None]; yy=y*sw; bb=np.linalg.lstsq(X,yy,rcond=None)[0]; r=yy-X@bb
    return bb[0], bb[0]/np.sqrt(r@r/(len(y)-X.shape[1])*np.linalg.pinv(X.T@X)[0,0])
def run(name,d,by,ycol,w=None,fe='STATE'):
    b,N,idx=B[by]; d=d.merge(b[['GISJOIN','STATE','S','cz']],on='GISJOIN',suffixes=('_x','')); ii=d.GISJOIN.map(idx).values
    fe_=pd.get_dummies(d[fe].astype(str),drop_first=True).values.astype(float); one=np.ones(len(d)); yv=d[ycol].values; ww=None if w is None else d[w].values.astype(float)
    out={'outcome':name,'n':len(d)}
    for lab,Z in [('no_cotton',np.column_stack([one,fe_])),('cotton',np.column_stack([one,fe_,d.cz,d.cz**2]))]:
        be,t=reg(d.S.values,Z,yv,ww); tn=np.array([reg(N[ii,k],Z,yv,ww)[1] for k in range(300)])
        out[f'beta_{lab}']=round(be,3); out[f't_{lab}']=round(t,1); out[f'noise95_{lab}']=round(np.quantile(abs(tn),.95),1)
    out['kept_%']=round(100*out['beta_cotton']/out['beta_no_cotton']); return out
res=[]
ts=pd.read_csv(glob.glob('/mnt/user-data/uploads/*ts_nominal_county.csv')[0],encoding='latin-1',dtype=str); ts['bs']=pd.to_numeric(ts.B18AB)/pd.to_numeric(ts.A00AA)
for yr in ['1970','2020']: res.append(run(f'black_share {yr}',ts[ts.YEAR==yr][['GISJOIN','bs']].dropna(),2020,'bs'))
p=pd.read_csv('panel_nominal.csv',dtype={'GISJOIN':str})
for yr,by in [(1900,1900),(1930,1930)]: res.append(run(f'black_share {yr}',p[p.YEAR==yr][['GISJOIN','bshare']].dropna(),by,'bshare'))
o=pd.read_csv('outcomes_long.csv',dtype={'GISJOIN':str})
w=o.pivot_table(index=['GISJOIN','year'],columns='outcome',values='y').reset_index(); ww=o.pivot_table(index=['GISJOIN','year'],columns='outcome',values='w').reset_index()
w['own_gap']=w.white_own-w.black_own; w=w.merge(ww[['GISJOIN','year','black_own','black_illit_m21']].rename(columns={'black_own':'w_own','black_illit_m21':'w_il'}),on=['GISJOIN','year'])
for yr,by in [(1900,1900),(1910,1900),(1920,1930),(1930,1930)]:
    d=w[(w.year==yr)&(w.w_own>=10)]; res.append(run(f'black_own {yr}',d[['GISJOIN','black_own']].dropna(),by,'black_own')); res.append(run(f'own_gap {yr}',d[['GISJOIN','own_gap']].dropna(),by,'own_gap'))
for yr,by in [(1900,1900),(1910,1900),(1920,1930)]:
    d=w[(w.year==yr)&(w.w_il>=50)]; res.append(run(f'black_illit {yr}',d[['GISJOIN','black_illit_m21']].dropna(),by,'black_illit_m21'))
v=pd.read_csv('imr_1959_72.csv',dtype={'GISJOIN':str}); v['imr']=1000*v.dn/v.bn
OK=['Alabama','Delaware','Florida','Georgia','Louisiana','Maryland','Mississippi','North Carolina','South Carolina']
v=v.merge(B[2020][0][['GISJOIN','STATE']],on='GISJOIN'); v=v[v.STATE.isin(OK)&(v.bn>=50)]; v['sy']=v.STATE+v.year.astype(str)
for nm,yrs in [('black_imr 1960-65',range(1960,1966)),('black_imr 1967-72',range(1967,1973))]:
    d=v[v.year.isin(yrs)][['GISJOIN','imr','bn','sy']]; res.append(run(nm,d,2020,'imr',w='bn',fe='sy'))
r=pd.DataFrame(res); print(r.to_string(index=False)); r.to_csv('h2_results_H.csv',index=False)
