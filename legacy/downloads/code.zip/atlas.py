import pandas as pd, numpy as np, geopandas as gpd, glob
rng=np.random.default_rng(6)
SS=['Alabama','Arkansas','Delaware','Florida','Georgia','Kentucky','Louisiana','Maryland','Mississippi','Missouri','North Carolina','South Carolina','Tennessee','Texas','Virginia','West Virginia']
FIPS={'01':'Alabama','05':'Arkansas','10':'Delaware','12':'Florida','13':'Georgia','21':'Kentucky','22':'Louisiana','24':'Maryland','28':'Mississippi','29':'Missouri','37':'North Carolina','45':'South Carolina','47':'Tennessee','48':'Texas','51':'Virginia','54':'West Virginia'}
def base(y):
    if y==2020:
        b=pd.read_csv('S1860_on_2020.csv',dtype={'GISJOIN':str}).rename(columns={'S20':'S'})
        g=gpd.read_file('shp/US_county_2020.shp',columns=['GISJOIN','STATEFP']); g['cx']=g.geometry.centroid.x/1000; g['cy']=g.geometry.centroid.y/1000
        b=b.merge(g.drop(columns='geometry'),on='GISJOIN'); b['STATE']=b.STATEFP.map(FIPS)
    else: b=pd.read_csv(f'S1860_on_{y}.csv',dtype={'GISJOIN':str})
    b=b.merge(pd.read_csv(f'cotton_{y}.csv',dtype={'GISJOIN':str}),on='GISJOIN')
    b=b[b.STATE.isin(SS)&(b.cover>=0.9)&b.S.notna()&b.cotton.notna()].reset_index(drop=True)
    b['cz']=(b.cotton-b.cotton.mean())/b.cotton.std()
    D=np.sqrt((b.cx.values[:,None]-b.cx.values[None])**2+(b.cy.values[:,None]-b.cy.values[None])**2)
    N=np.linalg.cholesky(np.exp(-D/180)+1e-6*np.eye(len(D)))@rng.standard_normal((len(D),300))
    return b,N,dict(zip(b.GISJOIN,range(len(b))))
B={2020:base(2020)}
for y,(b,_,_) in B.items():
    r=np.corrcoef(b.S,b.cotton)[0,1]; print(f'{y}: n={len(b)} corr(S,cotton)={r:.2f}')
def reg(v,Z,y,w=None):
    w=np.ones(len(y)) if w is None else w; sw=np.sqrt(w)
    X=np.column_stack([v,Z])*sw[:,None]; yy=y*sw; bb=np.linalg.lstsq(X,yy,rcond=None)[0]; r=yy-X@bb
    return bb[0], bb[0]/np.sqrt(r@r/(len(y)-X.shape[1])*np.linalg.pinv(X.T@X)[0,0])
def run(name,d,by,ycol,w=None,fe='STATE'):
    b,N,idx=B[by]; d=d.merge(b[['GISJOIN','STATE','S','cz']],on='GISJOIN',suffixes=('_x','')); ii=d.GISJOIN.map(idx).values
    fe_=pd.get_dummies(d[fe].astype(str),drop_first=True).values.astype(float); one=np.ones(len(d)); yv=d[ycol].values; ww=None if w is None else d[w].values.astype(float)
    out={'outcome':name,'n':len(d)}
    for lab,Z in [('no_cotton',np.column_stack([one,fe_])),('cotton',np.column_stack([one,fe_,d.cz,d.cz**2]))]:
        be,t=reg(d.S.values,Z,yv,ww); tn=np.array([reg(N[ii,k],Z,yv,ww)[1] for k in range(300)])
        out[f'beta_{lab}']=round(be,3); out[f't_{lab}']=round(t,1); out[f'noise95_{lab}']=round(np.quantile(abs(tn),.95),1)
    out['kept_%']=round(100*out['beta_cotton']/out['beta_no_cotton']); return out

import pandas as pd
V=['kfr','kir','jail','coll','hs','staycz','kfr_stycz']
cols=['state','county']+[f'{v}_{r}_{g}_{p}' for v in V for r in ['black','white'] for g in ['pooled','male'] for p in ['p25','p75','n']]
a=pd.read_csv('/mnt/user-data/uploads/county_outcomes.csv',usecols=lambda c: c in cols)
a['GISJOIN']='G'+a.state.astype(int).astype(str).str.zfill(2)+'0'+a.county.astype(int).astype(str).str.zfill(3)+'0'
d=a.copy()
specs=[('kfr_black_pooled_p25','kfr_black_pooled_n','Black adult household income rank, parents at p25'),
       ('kfr_black_pooled_p75','kfr_black_pooled_n','Black adult household income rank, parents at p75'),
       ('kfr_white_pooled_p25','kfr_white_pooled_n','White adult household income rank, parents at p25'),
       ('kfr_gap_p25','kfr_black_pooled_n','White minus Black income rank, parents at p25'),
       ('kir_black_male_p25','kir_black_male_n','Black men individual income rank, p25'),
       ('jail_black_male_p25','jail_black_male_n','Black men incarcerated 2010, p25'),
       ('jail_white_male_p25','jail_white_male_n','White men incarcerated 2010, p25'),
       ('hs_black_pooled_p25','hs_black_pooled_n','Black high school completion, p25'),
       ('coll_black_pooled_p25','coll_black_pooled_n','Black college attendance, p25'),
       ('staycz_black_pooled_p25','staycz_black_pooled_n','Black adults still in childhood commuting zone, p25'),
       ('kfr_stycz_black_pooled_p25','kfr_stycz_black_pooled_n','Black income rank among stayers, p25')]
d['kfr_gap_p25']=d.kfr_white_pooled_p25-d.kfr_black_pooled_p25
res=[]
for y,n,lab in specs:
    x=d[['GISJOIN',y,n]].dropna(); x=x[x[n]>=50]
    if len(x)<150: print('skip',y,len(x)); continue
    r=run(lab,x[['GISJOIN',y,n]].rename(columns={n:'wt'}),2020,y,w='wt'); r['mean']=round(x[y].mean(),3); res.append(r)
r=pd.DataFrame(res); pd.set_option('display.width',250); print(r.drop(columns=['noise95_no_cotton']).to_string(index=False)); r.to_csv('atlas_results.csv',index=False)
