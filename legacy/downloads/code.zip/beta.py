import pandas as pd, numpy as np
rng=np.random.default_rng(1)
p=pd.read_csv('panel_nominal.csv',dtype={'GISJOIN':str}).dropna(subset=['INTPTLAT','bshare','S'])
base=p[p.YEAR==1870][['GISJOIN','INTPTLAT','INTPTLON','S','STATE']].drop_duplicates('GISJOIN').reset_index(drop=True)
R=6371; la=np.radians(base.INTPTLAT.values); lo=np.radians(base.INTPTLON.values)
x=R*np.cos(la.mean())*lo; y=R*la
D=np.sqrt((x[:,None]-x[None])**2+(y[:,None]-y[None])**2)
# correlation length of S: fit exp(-d/L) to empirical correlogram
z=(base.S-base.S.mean())/base.S.std(); bins=np.arange(0,600,25); cc=[]
iu=np.triu_indices(len(z),1); dd=D[iu]; pr=(z.values[:,None]*z.values[None])[iu]
for a,b_ in zip(bins[:-1],bins[1:]):
    m=(dd>=a)&(dd<b_); cc.append(pr[m].mean())
cc=np.array(cc); mid=bins[:-1]+12.5
Ls=np.arange(20,600,5); err=[((np.exp(-mid/L)*cc[0]/np.exp(-mid[0]/L)-cc)**2).sum() for L in Ls]
L=Ls[int(np.argmin(err))]; print('S correlation length (km):',L, ' correlogram:',np.round(cc[:8],2))
K=np.exp(-D/L)+1e-6*np.eye(len(D)); Ch=np.linalg.cholesky(K)
noise=Ch@rng.standard_normal((len(D),1000))
idx=dict(zip(base.GISJOIN,range(len(base))))
def design(df,trend):
    X=[np.ones(len(df))]; st=pd.get_dummies(df.STATE,drop_first=True).values.astype(float); X.append(st)
    if trend:
        la_=df.INTPTLAT.values; lo_=df.INTPTLON.values
        X+= [la_,lo_,la_**2,lo_**2,la_*lo_]
    return np.column_stack([X[0]]+X[1:])
def tstat(v,Z,yv):
    X=np.column_stack([v,Z]); b,_,_,_=np.linalg.lstsq(X,yv,rcond=None); r=yv-X@b
    XtXi=np.linalg.pinv(X.T@X); se=np.sqrt(r@r/(len(yv)-X.shape[1])*XtXi[0,0]); return b[0],b[0]/se,r
def moran(r,ii):
    W=np.exp(-D[np.ix_(ii,ii)]/L); np.fill_diagonal(W,0); W/=W.sum(1,keepdims=True); r=r-r.mean()
    return len(r)/W.sum()*(r@W@r)/(r@r)
out=[]
for trend in [False,True]:
  for yr,df in p.groupby('YEAR'):
    df=df.drop_duplicates('GISJOIN'); ii=np.array([idx[g] for g in df.GISJOIN if g in idx]); df=df[df.GISJOIN.isin(idx)]
    Z=design(df,trend); yv=df.bshare.values
    b,t,r=tstat(df.S.values,Z,yv)
    tn=np.array([tstat(noise[ii,k],Z,yv)[1] for k in range(500)])
    # reverse test: S explaining noise outcome
    tr=np.array([tstat(df.S.values,Z,noise[ii,k])[1] for k in range(200)])
    out.append(dict(trend=trend,year=yr,n=len(df),beta=round(b,3),t=round(t,1),
      p_noise=(np.abs(tn)>=abs(t)).mean(),noise_t95=round(np.quantile(np.abs(tn),.95),1),
      S_fits_noise_p05=round((np.abs(tr)>1.96).mean(),2),moran=round(moran(r,ii),2)))
o=pd.DataFrame(out); print(o.to_string(index=False)); o.to_csv('beta_t.csv',index=False)
