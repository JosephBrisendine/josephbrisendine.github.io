# Innovation at t0 = part of Black-share map at t0 not predicted by the map at t0-10 (and 1860) + controls.
# Survival s(t|t0) = coefficient of later map on that innovation, holding the earlier maps fixed. Aging test: does s depend on t0 at fixed lag?
import pandas as pd, numpy as np, geopandas as gpd
rng=np.random.default_rng(14)
g=gpd.read_file('shp/US_county_2020.shp')[['GISJOIN','STATEFP','geometry']]; g['cx']=g.centroid.x/1000; g['cy']=g.centroid.y/1000
FIPS=['01','05','10','12','13','21','22','24','28','29','37','45','47','48','51','54']
P=pd.read_csv('panel2020.csv',dtype={'GISJOIN':str})
Y=[1870,1880,1890,1900,1910,1920,1930,1940,1950,1960,1970,1980,1990,2000,2010,2020]
W=P[P.year.isin(Y+[2024])].pivot(index='GISJOIN',columns='year',values='bshare')
b=g[g.STATEFP.isin(FIPS)].drop(columns='geometry').merge(pd.read_csv('S1860_on_2020.csv',dtype={'GISJOIN':str})[['GISJOIN','S20']],on='GISJOIN').merge(pd.read_csv('cotton_2020.csv',dtype={'GISJOIN':str}),on='GISJOIN')
b=b.merge(P[P.year==1860][['GISJOIN','logdens']].rename(columns={'logdens':'ld60'}),on='GISJOIN').merge(W,left_on='GISJOIN',right_index=True)
import sys
if len(sys.argv)>1: b=b[b.GISJOIN.isin(pd.read_csv('stable_counties.csv').GISJOIN)]
b=b.dropna().reset_index(drop=True); b['cz']=(b.cotton-b.cotton.mean())/b.cotton.std(); print('balanced counties',len(b))
fe=pd.get_dummies(b.STATEFP,drop_first=True).values.astype(float); Z0=np.column_stack([np.ones(len(b)),fe,b.cz,b.cz**2,b.ld60,b.S20])
D=np.sqrt((b.cx.values[:,None]-b.cx.values[None])**2+(b.cy.values[:,None]-b.cy.values[None])**2)
N=np.linalg.cholesky(np.exp(-D/180)+1e-6*np.eye(len(b)))@rng.standard_normal((len(b),200))
mean={y:b[y].mean() for y in Y+[2024]}
def resid(v,X): return v-X@np.linalg.lstsq(X,v,rcond=None)[0]
rows=[]
for t0 in Y:
    prev=[y for y in Y if y<t0]
    X=np.column_stack([Z0]+[b[y] for y in prev])          # everything known before t0
    e=resid(b[t0].values,X); sd=e.std()
    for t in [y for y in Y+[2024] if y>=t0]:
        Xf=np.column_stack([e,X]); c=np.linalg.lstsq(Xf,b[t].values,rcond=None)[0]; r=b[t].values-Xf@c
        se=np.sqrt(r@r/(len(b)-Xf.shape[1])*np.linalg.pinv(Xf.T@Xf)[0,0])
        tn=[]
        if t>t0:
            for k in range(200):
                nk=resid(N[:,k],X); nk*=sd/nk.std(); Xn=np.column_stack([nk,X]); cn=np.linalg.lstsq(Xn,b[t].values,rcond=None)[0]; rn=b[t].values-Xn@cn
                tn.append(abs(cn[0]/np.sqrt(rn@rn/(len(b)-Xn.shape[1])*np.linalg.pinv(Xn.T@Xn)[0,0])))
        rows.append(dict(t0=t0,t=t,lag=t-t0,sd_innov=sd,s=c[0],s_amp=c[0]*mean[t0]/mean[t],t_stat=c[0]/se if t>t0 else np.nan,noise95=np.quantile(tn,.95) if tn else np.nan))
r=pd.DataFrame(rows); r.to_csv('age_spectrum'+('_stable' if len(sys.argv)>1 else '')+'.csv',index=False)
print(r.assign(cell=r.s_amp.round(2).astype(str)+np.where(abs(r.t_stat)>r.noise95,'*','')).pivot(index='t0',columns='lag',values='cell').fillna('').to_string())
print('\ninnovation sd by t0:',r.drop_duplicates('t0').set_index('t0').sd_innov.round(4).to_dict())
