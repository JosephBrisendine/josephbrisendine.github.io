import pandas as pd, numpy as np, geopandas as gpd, glob
R='raw22/nhgis0022_csv/'
g20=gpd.read_file('shp/US_county_2020.shp')
FIPS=['01','05','10','12','13','21','22','24','28','29','37','45','47','48','51','54']
g20=g20[g20.STATEFP.isin(FIPS)][['GISJOIN','geometry']].rename(columns={'GISJOIN':'G20'}); g20['a20']=g20.area
shp={1860:'US_county_1860_conflated',1900:'US_county_1900_conflated',1930:'US_county_1930_conflated'}
def sy(y): return 1860 if y<=1880 else (1900 if y<=1910 else 1930)
cache={}; out=[]
for f in sorted(glob.glob(R+'nhgis0022_ds11_*_county.csv')):
    y=int(f.split('_')[-2]); d=pd.read_csv(f,encoding='latin-1',dtype={'GISJOIN':str})
    d['v']=pd.to_numeric(d.AE7001,errors='coerce'); d=d[d.v>0][['GISJOIN','v']]
    s=sy(y)
    if s not in cache:
        gs=gpd.read_file(f'shp/{shp[s]}.shp')[['GISJOIN','geometry']].to_crs(g20.crs)
        cache[s]=gpd.overlay(gs,g20,how='intersection',keep_geom_type=True); cache[s]['ia']=cache[s].area
    x=cache[s].merge(d,on='GISJOIN',how='inner'); x['lv']=np.log(x.v)
    a=x.groupby('G20').apply(lambda z: pd.Series({'lfv':np.average(z.lv,weights=z.ia),'cov':z.ia.sum()}),include_groups=False).reset_index().merge(g20[['G20','a20']],on='G20')
    a=a[a['cov']/a.a20>=0.8]; a['year']=y; out.append(a[['G20','year','lfv']].rename(columns={'G20':'GISJOIN'})); print(y,len(d),len(a))
pd.concat(out).to_csv('farmval2020.csv',index=False)
