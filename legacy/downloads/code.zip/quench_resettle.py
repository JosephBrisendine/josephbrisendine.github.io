import pandas as pd, numpy as np, geopandas as gpd
rng=np.random.default_rng(13)
g=gpd.read_file('shp/US_county_2020.shp')[['GISJOIN','STATEFP','geometry']]; g['cx']=g.centroid.x/1000; g['cy']=g.centroid.y/1000
FIPS=['01','05','10','12','13','21','22','24','28','29','37','45','47','48','51','54']
P=pd.read_csv('panel2020.csv',dtype={'GISJOIN':str})
b=g[g.STATEFP.isin(FIPS)].drop(columns='geometry').merge(pd.read_csv('S1860_on_2020.csv',dtype={'GISJOIN':str})[['GISJOIN','S20']],on='GISJOIN').merge(pd.read_csv('cotton_2020.csv',dtype={'GISJOIN':str}),on='GISJOIN')
b=b.merge(P[P.year==1860][['GISJOIN','logdens']].rename(columns={'logdens':'ld60'}),on='GISJOIN').merge(P[P.year==1870][['GISJOIN','bshare']].rename(columns={'bshare':'b70'}),on='GISJOIN')
b=b.dropna().reset_index(drop=True); b['cz']=(b.cotton-b.cotton.mean())/b.cotton.std()
fe=pd.get_dummies(b.STATEFP,drop_first=True).values.astype(float)
Z0=np.column_stack([np.ones(len(b)),fe,b.cz,b.cz**2,b.ld60])
X=np.column_stack([b.S20,Z0]); bb=np.linalg.lstsq(X,b.b70,rcond=None)[0]; b['r70']=b.b70-X@bb   # 1865-70 resettlement: part of 1870 map not predicted by 1860
print('n',len(b),'sd(r70)=',round(b.r70.std(),3),' R2 of 1870 on 1860+controls=',round(1-b.r70.var()/b.b70.var(),3))
D=np.sqrt((b.cx.values[:,None]-b.cx.values[None])**2+(b.cy.values[:,None]-b.cy.values[None])**2)
N=np.linalg.cholesky(np.exp(-D/180)+1e-6*np.eye(len(b)))@rng.standard_normal((len(b),300)); idx=dict(zip(b.GISJOIN,range(len(b))))
def fit(v,W,y):
    X=np.column_stack([v,W]); c=np.linalg.lstsq(X,y,rcond=None)[0]; r=y-X@c; se=np.sqrt(r@r/(len(y)-X.shape[1])*np.linalg.pinv(X.T@X).diagonal())
    return c,se
rows=[]
for y in [1870,1880,1890,1900,1910,1920,1930,1940,1950,1960,1970,1980,1990,2000,2010,2020,2024]:
    d=b.merge(P[P.year==y][['GISJOIN','bshare']],on='GISJOIN').dropna(); ii=d.GISJOIN.map(idx).values
    W=np.column_stack([d.S20,Z0[ii]]); c,se=fit(d.r70.values,W,d.bshare.values)
    tn=[]
    for k in range(200):
        # noise null for the resettlement term: replace r70 by spatial noise orthogonalised the same way
        nk=N[ii,k]; nk=nk-np.column_stack([d.S20,Z0[ii]])@np.linalg.lstsq(np.column_stack([d.S20,Z0[ii]]),nk,rcond=None)[0]
        cc,ss=fit(nk*d.r70.std()/nk.std(),W,d.bshare.values); tn.append(abs(cc[0]/ss[0]))
    m=d.bshare.mean()
    rows.append(dict(year=y,n=len(d),beta_r70=c[0],t_r70=c[0]/se[0],noise95=np.quantile(tn,.95),beta_S=c[1],t_S=c[1]/se[1],mean=m))
r=pd.DataFrame(rows); r['rel_r70']=r.beta_r70/r.beta_r70.iloc[0]; r['rel_S']=(r.beta_S/r['mean'])/(r.beta_S.iloc[0]/r['mean'].iloc[0])
r['rel_r70_amp']=(r.beta_r70/r['mean'])/(r.beta_r70.iloc[0]/r['mean'].iloc[0])
print(r.round(3).to_string(index=False)); r.to_csv('resettlement_memory.csv',index=False)
