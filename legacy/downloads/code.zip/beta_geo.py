import pandas as pd, numpy as np, geopandas as gpd, glob
rng=np.random.default_rng(4)
g=gpd.read_file('shp/US_county_2020.shp',columns=['GISJOIN','STATEFP'])
g['cx']=g.geometry.centroid.x/1000; g['cy']=g.geometry.centroid.y/1000
c=pd.read_csv('S1860_on_2020.csv',dtype={'GISJOIN':str})
ST={'01':'AL','05':'AR','10':'DE','12':'FL','13':'GA','21':'KY','22':'LA','24':'MD','28':'MS','29':'MO','37':'NC','45':'SC','47':'TN','48':'TX','51':'VA','54':'WV'}
b=g.drop(columns='geometry').merge(c,on='GISJOIN'); b=b[b.STATEFP.isin(ST)&(b.cover>=0.9)&b.S20.notna()].reset_index(drop=True)
print('counties',len(b), ' WV:',(b.STATEFP=='54').sum())
D=np.sqrt((b.cx.values[:,None]-b.cx.values[None])**2+(b.cy.values[:,None]-b.cy.values[None])**2)
Ch=np.linalg.cholesky(np.exp(-D/180)+1e-6*np.eye(len(D))); noise=Ch@rng.standard_normal((len(D),400)); idx=dict(zip(b.GISJOIN,range(len(b))))
ts=pd.read_csv(glob.glob('/mnt/user-data/uploads/*ts_nominal_county.csv')[0],encoding='latin-1',dtype=str)
ts=ts[ts.YEAR.astype(int)>=1970]; ts['bs']=pd.to_numeric(ts.B18AB)/pd.to_numeric(ts.A00AA)
def reg(v,Z,y):
    X=np.column_stack([v,Z]); bb=np.linalg.lstsq(X,y,rcond=None)[0]; r=y-X@bb
    return bb[0], bb[0]/np.sqrt(r@r/(len(y)-X.shape[1])*np.linalg.pinv(X.T@X)[0,0])
old=pd.read_csv('beta_t.csv'); old=old[~old.trend].set_index('year')
res=[]
for yr,d in ts.groupby('YEAR'):
    d=d[['GISJOIN','bs']].merge(b[['GISJOIN','STATEFP','S20']],on='GISJOIN').dropna()
    Z=np.column_stack([np.ones(len(d)),pd.get_dummies(d.STATEFP,drop_first=True).values.astype(float)]); ii=d.GISJOIN.map(idx).values
    be,t=reg(d.S20.values,Z,d.bs.values); tn=np.array([reg(noise[ii,k],Z,d.bs.values)[1] for k in range(400)])
    res.append(dict(year=int(yr),n=len(d),beta=round(be,3),t=round(t,1),noise95=round(np.quantile(abs(tn),.95),1),beta_nominal=old.beta.get(int(yr)),n_nominal=old.n.get(int(yr))))
print(pd.DataFrame(res).to_string(index=False))
