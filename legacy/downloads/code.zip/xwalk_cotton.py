import geopandas as gpd, pandas as pd, numpy as np
a=pd.read_csv('raw17/nhgis0017_csv/nhgis0017_ds13_1860_county.csv',encoding='latin-1',dtype={'GISJOIN':str})
a['bales']=pd.to_numeric(a.AGY007,errors='coerce').fillna(0); a['impr']=pd.to_numeric(a.AGP001,errors='coerce').fillna(0)
g60=gpd.read_file('shp/US_county_1860_conflated.shp')[['GISJOIN','geometry']].merge(a[['GISJOIN','bales','impr']],on='GISJOIN'); g60['a60']=g60.area
print('US 1860 bales:',int(a.bales.sum()))
for y,f in [(1900,'shp/US_county_1900_conflated.shp'),(1930,'shp/US_county_1930_conflated.shp'),(2020,'shp/US_county_2020.shp')]:
    g=gpd.read_file(f,columns=['GISJOIN']).to_crs(g60.crs).rename(columns={'GISJOIN':'GJ'})
    x=gpd.overlay(g60,g,how='intersection',keep_geom_type=True); fr=x.area/x.a60
    x['b']=x.bales*fr; x['i']=x.impr*fr
    c=x.groupby('GJ')[['b','i']].sum().reset_index().rename(columns={'GJ':'GISJOIN'})
    c['cot1860']=np.log1p(1000*c.b/c.i.where(c.i>0))   # log(1 + bales per 1000 improved acres)
    c.to_csv(f'cotton1860_on_{y}.csv',index=False); print(y,len(c),c.cot1860.describe().round(2).to_dict())
