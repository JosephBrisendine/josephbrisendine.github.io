import pandas as pd, numpy as np, geopandas as gpd, glob
rng=np.random.default_rng(6)
SS=['Alabama','Arkansas','Delaware','Florida','Georgia','Kentucky','Louisiana','Maryland','Mississippi','Missouri','North Carolina','South Carolina','Tennessee','Texas','Virginia','West Virginia']
FIPS={'01':'Alabama','05':'Arkansas','10':'Delaware','12':'Florida','13':'Georgia','21':'Kentucky','22':'Louisiana','24':'Maryland','28':'Mississippi','29':'Missouri','37':'North Carolina','45':'South Carolina','47':'Tennessee','48':'Texas','51':'Virginia','54':'West Virginia'}
def base(y):
    if y==2020:
        b=pd.read_csv('S1860_on_2020.csv',dtype={'GISJOIN':str}).rename(columns={'S20':'S'})
        g=gpd.read_file('shp/US_county_2020.shp',columns=['GISJOIN','STATEFP']); g['cx']=g.geometry.centroid.x/1000; g['cy']=g.geometry.centroid.y/1000
        b=b.merge(g.drop(columns='geometry'),on='GISJOIN'); b['STATE']=b.STATEFP.map(FIPS)
    else: b=pd.read_csv(f'S1860_on_{y}.csv',dtype={'GISJOIN':str})
    b=b.merge(pd.read_csv(f'cotton_{y}.csv',dtype={'GISJOIN':str}),on='GISJOIN')
    b=b[b.STATE.isin(SS)&(b.cover>=0.9)&b.S.notna()&b.cotton.notna()].reset_index(drop=True)
    b['cz']=(b.cotton-b.cotton.mean())/b.cotton.std()
    b=b.merge(pd.read_csv(f'cotton1860_on_{y}.csv',dtype={'GISJOIN':str})[['GISJOIN','cot1860']],on='GISJOIN'); b=b[b.cot1860.notna()].reset_index(drop=True); b['c2']=(b.cot1860-b.cot1860.mean())/b.cot1860.std()
    D=np.sqrt((b.cx.values[:,None]-b.cx.values[None])**2+(b.cy.values[:,None]-b.cy.values[None])**2)
    N=np.linalg.cholesky(np.exp(-D/180)+1e-6*np.eye(len(D)))@rng.standard_normal((len(D),300))
    return b,N,dict(zip(b.GISJOIN,range(len(b))))

B={y:base(y) for y in [2020]}
for y,(b,_,_) in B.items(): print(y,'n',len(b),'corr(S,GAEZ)',round(np.corrcoef(b.S,b.cz)[0,1],2),'corr(S,cotton1860)',round(np.corrcoef(b.S,b.c2)[0,1],2))
def reg(v,Z,y,w=None):
    w=np.ones(len(y)) if w is None else w; sw=np.sqrt(w)
    X=np.column_stack([v,Z])*sw[:,None]; yy=y*sw; bb=np.linalg.lstsq(X,yy,rcond=None)[0]; r=yy-X@bb
    return bb[0], bb[0]/np.sqrt(r@r/(len(y)-X.shape[1])*np.linalg.pinv(X.T@X)[0,0])
def run4(name,d,by,ycol,w=None,fe='STATE'):
    b,N,idx=B[by]; d=d.merge(b[['GISJOIN','STATE','S','cz','c2']],on='GISJOIN',suffixes=('_x','')); ii=d.GISJOIN.map(idx).values
    F=pd.get_dummies(d[fe].astype(str),drop_first=True).values.astype(float); one=np.ones(len(d)); yv=d[ycol].values; ww=None if w is None else d[w].values.astype(float)
    out={'outcome':name,'n':len(d)}
    for lab,Z in [('none',[one,F]),('GAEZ',[one,F,d.cz,d.cz**2]),('cot1860',[one,F,d.c2,d.c2**2]),('both',[one,F,d.cz,d.cz**2,d.c2,d.c2**2])]:
        Z=np.column_stack(Z); be,t=reg(d.S.values,Z,yv,ww); tn=np.array([reg(N[ii,k],Z,yv,ww)[1] for k in range(150)])
        out[lab]=f"{be:+.3f} ({t:.1f}/{np.quantile(abs(tn),.95):.1f})"
    return out


a=pd.read_csv('raw19/nhgis0019_csv/nhgis0019_ds262_20225_county.csv',encoding='latin-1',dtype={'GISJOIN':str},low_memory=False)
f=lambda c: pd.to_numeric(a[c],errors='coerce')
d=pd.DataFrame({'GISJOIN':a.GISJOIN,'aw':f('AQP8E001'),'ab':f('AQP9E001'),'mab':f('AQP9M001')})
t=pd.read_csv('raw9/nhgis0009_csv/nhgis0009_ts_nominal_county.csv',encoding='latin-1',dtype={'GISJOIN':str})
g=lambda c: pd.to_numeric(t[c],errors='coerce')
h=pd.DataFrame({'GISJOIN':t.GISJOIN,'hhw':g('B39AA2020')+g('B39AE2020'),'hhb':g('B39AB2020')+g('B39AF2020')})
d=d.merge(h,on='GISJOIN'); d=d[(d.hhb>=50)&(d.ab>0)&(d.aw>0)&(d.mab/d.ab<0.5)]
d['mb']=d.ab/d.hhb; d['mw']=d.aw/d.hhw; d['lmb']=np.log(d.mb); d['lr']=np.log(d.mb/d.mw)
print('counties',len(d),' median Black/white mean-income ratio',round((d.mb/d.mw).median(),2))
res=[run4('Black mean household income 2018-22 (log)',d[['GISJOIN','lmb']],2020,'lmb'),run4('Black/white mean household income 2018-22 (log ratio)',d[['GISJOIN','lr']],2020,'lr')]
# same-sample comparison with 2008-12 medians
a2=pd.read_csv('raw18/nhgis0018_csv/nhgis0018_ds191_20125_county.csv',encoding='latin-1',dtype={'GISJOIN':str},low_memory=False)
m=pd.DataFrame({'GISJOIN':a2.GISJOIN,'hw':pd.to_numeric(a2.QU2E001,errors='coerce'),'hb':pd.to_numeric(a2.QU3E001,errors='coerce'),'mb12':pd.to_numeric(a2.QU3M001,errors='coerce')})
m=m[(m.hb>0)&(m.hw>0)&(m.mb12/m.hb<0.5)]; m['lr12']=np.log(m.hb/m.hw)
both=d.merge(m[['GISJOIN','lr12']],on='GISJOIN')
res.append(run4('SAME COUNTIES: 2008-12 median ratio',both[['GISJOIN','lr12']],2020,'lr12'))
res.append(run4('SAME COUNTIES: 2018-22 mean ratio',both[['GISJOIN','lr']],2020,'lr'))
r=pd.DataFrame(res); pd.set_option('display.width',250); print('cells: beta (t / noise 95%)'); print(r.to_string(index=False)); r.to_csv('income2022_results.csv',index=False)
