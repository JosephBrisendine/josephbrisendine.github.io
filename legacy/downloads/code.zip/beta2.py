import pandas as pd, numpy as np
rng=np.random.default_rng(2)
s=pd.read_csv('s1860_nominal.csv',dtype={'GISJOIN':str})
SS=['Alabama','Arkansas','Delaware','Florida','Georgia','Kentucky','Louisiana','Maryland','Mississippi','Missouri','North Carolina','South Carolina','Tennessee','Texas','Virginia']
s=s[s.STATE.isin(SS)&s.S.notna()]
c=pd.read_csv(__import__('glob').glob('/mnt/user-data/uploads/*ds181_2010_county.csv')[0],encoding='latin-1',dtype={'GISJOIN':str})[['GISJOIN','INTPTLAT','INTPTLON']]
base=s.merge(c,on='GISJOIN').reset_index(drop=True)
R=6371; la=np.radians(base.INTPTLAT.values); lo=np.radians(base.INTPTLON.values)
x=R*np.cos(la.mean())*lo; y=R*la; D=np.sqrt((x[:,None]-x[None])**2+(y[:,None]-y[None])**2)
L=180; Ch=np.linalg.cholesky(np.exp(-D/L)+1e-6*np.eye(len(D))); noise=Ch@rng.standard_normal((len(D),500))
idx=dict(zip(base.GISJOIN,range(len(base))))
o=pd.read_csv('outcomes_long.csv',dtype={'GISJOIN':str})
w=o.pivot_table(index=['GISJOIN','year'],columns='outcome',values='y').reset_index()
ww=o.pivot_table(index=['GISJOIN','year'],columns='outcome',values='w').reset_index()
w['own_gap']=w.white_own-w.black_own
w['imr_ratio']=w.black_imr/w.white_imr
mins={'black_own':10,'white_own':10,'own_gap':10,'black_illit_m21':50,'black_imr':50,'white_imr':50,'imr_ratio':50}
def reg(v,Z,yv):
    X=np.column_stack([v,Z]); b=np.linalg.lstsq(X,yv,rcond=None)[0]; r=yv-X@b
    se=np.sqrt(r@r/(len(yv)-X.shape[1])*np.linalg.pinv(X.T@X)[0,0]); return b[0],b[0]/se
res=[]
for out,mn in mins.items():
    wkey='black_own' if out=='own_gap' else ('black_imr' if out=='imr_ratio' else out)
    for yr in sorted(w.year.unique()):
        d=w[w.year==yr][['GISJOIN',out]].merge(ww[ww.year==yr][['GISJOIN',wkey]].rename(columns={wkey:'wt'}),on='GISJOIN').merge(base[['GISJOIN','STATE','S']],on='GISJOIN')
        d=d[(d.wt>=mn)&np.isfinite(d[out])]
        if len(d)<150: continue
        Z=np.column_stack([np.ones(len(d)),pd.get_dummies(d.STATE,drop_first=True).values.astype(float)])
        ii=d.GISJOIN.map(idx).values; b,t=reg(d.S.values,Z,d[out].values)
        tn=np.array([reg(noise[ii,k],Z,d[out].values)[1] for k in range(300)])
        res.append(dict(outcome=out,year=yr,n=len(d),mean=round(d[out].mean(),3),beta=round(b,3),t=round(t,1),noise95=round(np.quantile(abs(tn),.95),1),p_noise=round((abs(tn)>=abs(t)).mean(),3)))
r=pd.DataFrame(res); r.to_csv('beta_outcomes.csv',index=False); print(r.to_string(index=False))
