import geopandas as gpd, pandas as pd, glob
g60=gpd.read_file('shp/US_county_1860_conflated.shp')[['GISJOIN','geometry']]
f20=glob.glob('shp/*2020*.shp')[0]; g20=gpd.read_file(f20); print(g20.columns.tolist()[:12], g20.crs==g60.crs)
g20=g20.to_crs(g60.crs)[['GISJOIN','geometry']]
s=pd.read_csv('s1860_nominal.csv',dtype={'GISJOIN':str})[['GISJOIN','STATE','enslaved','tot']]
g60=g60.merge(s,on='GISJOIN',how='inner'); g60['a60']=g60.area
x=gpd.overlay(g60,g20.rename(columns={'GISJOIN':'GJ20'}),how='intersection',keep_geom_type=True)
x['ia']=x.area; x['frac']=x.ia/x.a60
x['ens']=x.enslaved*x.frac; x['pp']=x.tot*x.frac
c=x.groupby('GJ20')[['ens','pp']].sum().reset_index()
a20=g20.set_index('GISJOIN').area; cov=x.groupby('GJ20').ia.sum()/a20.reindex(x.GJ20.unique())  # share of 2020 area covered by 1860 counties with data
c['S20']=c.ens/c.pp; c['cover']=c.GJ20.map(cov)
# dominant 1860 state for each 2020 county
st=x.sort_values('frac').groupby('GJ20').STATE.last(); c['STATE60']=c.GJ20.map(st)
c=c.rename(columns={'GJ20':'GISJOIN'}); c.to_csv('S1860_on_2020.csv',index=False)
print(c.describe().round(3)); print(len(c))
