import geopandas as gpd, pandas as pd, numpy as np
num=lambda s: pd.to_numeric(s,errors='coerce')
a50=pd.read_csv('/mnt/user-data/uploads/61e1ef99-nhgis0001_ds10_1850_county.csv',encoding='latin-1',dtype={'GISJOIN':str})
d50=pd.DataFrame({'GISJOIN':a50.GISJOIN,'white50':num(a50.AE6001),'slaves50':num(a50.AE6003)}); d50['tot50']=num(a50.AE6001)+num(a50.AE6002)+num(a50.AE6003)
e=pd.read_csv('raw17/nhgis0017_csv/nhgis0017_ds10_1850_county.csv',encoding='latin-1',dtype={'GISJOIN':str})
d50['wilit50']=num(e.AD8001)+num(e.AD8002); d50['wschool50']=num(e.AD4001)+num(e.AD4002)
f=pd.read_csv('raw17/nhgis0017_csv/nhgis0017_ds9_1850_county.csv',encoding='latin-1',dtype={'GISJOIN':str})
d50=d50.merge(pd.DataFrame({'GISJOIN':f.GISJOIN,'bales50':num(f.ADM007)}),on='GISJOIN',how='left')
print('1850 slaves:',int(d50.slaves50.sum()),' bales:',int(d50.bales50.sum()))
s60=pd.read_csv('s1860_nominal.csv',dtype={'GISJOIN':str})[['GISJOIN','enslaved','tot']]
a=pd.read_csv('raw17/nhgis0017_csv/nhgis0017_ds13_1860_county.csv',encoding='latin-1',dtype={'GISJOIN':str})
c60=pd.DataFrame({'GISJOIN':a.GISJOIN,'bales60':num(a.AGY007).fillna(0),'impr60':num(a.AGP001).fillna(0)})
g60=gpd.read_file('shp/US_county_1860_conflated.shp')[['GISJOIN','geometry']].merge(s60,on='GISJOIN').merge(c60,on='GISJOIN',how='left').merge(d50,on='GISJOIN',how='left')
g60['has50']=g60.tot50.notna().astype(float); g60['a60']=g60.area
print('1860 counties with a nominal 1850 match:',int(g60.has50.sum()),'of',len(g60))
V=['enslaved','tot','slaves50','tot50','white50','wilit50','wschool50','bales50','bales60','impr60']
for y,fn in [(1900,'shp/US_county_1900_conflated.shp'),(2020,'shp/US_county_2020.shp')]:
    g=gpd.read_file(fn,columns=['GISJOIN']).to_crs(g60.crs).rename(columns={'GISJOIN':'GJ'}); g['aT']=g.area
    x=gpd.overlay(g60,g,how='intersection',keep_geom_type=True); x['ia']=x.area; fr=x.ia/x.a60
    for v in V: x[v]=x[v].fillna(0)*fr
    x['ia50']=x.ia*x.has50
    c=x.groupby('GJ').agg(**{v:(v,'sum') for v in V},ia=('ia','sum'),ia50=('ia50','sum'),aT=('aT','first')).reset_index().rename(columns={'GJ':'GISJOIN'})
    c['cover50']=c.ia50/c.aT; c['S60']=c.enslaved/c.tot; c['S50']=c.slaves50/c.tot50
    c['wilit50_rate']=c.wilit50/c.white50; c['wschool50_rate']=c.wschool50/c.white50
    c['cot50']=np.log1p(1000*c.bales50/c.tot50); c.to_csv(f'v1850_on_{y}.csv',index=False)
    ok=c[c.cover50>=0.9]; print(y,'counties with >=90% 1850 coverage:',len(ok),' corr(S50,S60)=',round(ok[['S50','S60']].corr().iloc[0,1],3))
