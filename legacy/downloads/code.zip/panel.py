import pandas as pd, numpy as np, glob
U='/mnt/user-data/uploads/'
def rd(pat): 
    f=glob.glob(U+'*'+pat); assert len(f)==1,pat; return pd.read_csv(f[0],encoding='latin-1',dtype={'GISJOIN':str})
ts=pd.read_csv(glob.glob(U+'*ts_nominal_county.csv')[0],encoding='latin-1',dtype=str)
tot=ts[['GISJOIN','YEAR','A00AA']].copy(); tot['YEAR']=tot.YEAR.astype(int); tot['tot']=pd.to_numeric(tot.A00AA,errors='coerce')
rows=[]
def add(y,df,blackcols):
    d=df[['GISJOIN']].copy(); d['black']=df[blackcols].sum(axis=1); d['YEAR']=y; rows.append(d)
add(1870,rd('ds17_1870_county.csv'),['AK3002'])
add(1880,rd('ds23_1880_county.csv'),['APP002'])
add(1890,rd('ds27_1890_county.csv'),['AV0007','AV0008'])
add(1900,rd('ds31_1900_county.csv'),['AZ3003','AZ3004'])
add(1910,rd('ds37_1910_county.csv'),['A30003','A30004'])
add(1920,rd('ds43_1920_county.csv'),['A8L005','A8L006'])
add(1930,rd('ds53_1930_county.csv'),['BDK003','BDK004'])
add(1940,rd('ds77_1940_county.csv'),['BV2003','BV2004'])
add(1950,rd('nhgis0003_ds83_1950_county.csv'),['B1R%03d'%i for i in range(18,35)])
add(1960,rd('ds91_1960_county.csv'),['B5S002','B5S009'])
b=ts[ts.YEAR.astype(int)>=1970][['GISJOIN','YEAR','B18AB']].copy(); b['YEAR']=b.YEAR.astype(int); b['black']=pd.to_numeric(b.B18AB,errors='coerce'); rows.append(b[['GISJOIN','black','YEAR']])
p=pd.concat(rows).merge(tot[['GISJOIN','YEAR','tot']],on=['GISJOIN','YEAR'],how='left')
p['bshare']=p.black/p.tot
s=pd.read_csv('s1860_nominal.csv',dtype={'GISJOIN':str})[['GISJOIN','STATE','COUNTY','S','tot']].rename(columns={'tot':'tot1860'})
slave_states=['Alabama','Arkansas','Delaware','Florida','Georgia','Kentucky','Louisiana','Maryland','Mississippi','Missouri','North Carolina','South Carolina','Tennessee','Texas','Virginia']
s=s[s.STATE.isin(slave_states)&s.S.notna()]
c=rd('ds181_2010_county.csv')[['GISJOIN','INTPTLAT','INTPTLON']]
p=p.merge(s,on='GISJOIN').merge(c,on='GISJOIN',how='left')
p.to_csv('panel_nominal.csv',index=False)
print(p.groupby('YEAR').agg(n=('GISJOIN','size'),bshare=('bshare','mean'),nocoord=('INTPTLAT',lambda x:x.isna().sum())))
print(p[p.COUNTY.isin(['Mitchell','Dougherty'])&(p.STATE=='Georgia')].pivot(index='YEAR',columns='COUNTY',values='bshare').round(3))
