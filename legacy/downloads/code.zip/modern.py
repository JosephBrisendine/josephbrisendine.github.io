import pandas as pd, numpy as np, geopandas as gpd, glob
rng=np.random.default_rng(6)
SS=['Alabama','Arkansas','Delaware','Florida','Georgia','Kentucky','Louisiana','Maryland','Mississippi','Missouri','North Carolina','South Carolina','Tennessee','Texas','Virginia','West Virginia']
FIPS={'01':'Alabama','05':'Arkansas','10':'Delaware','12':'Florida','13':'Georgia','21':'Kentucky','22':'Louisiana','24':'Maryland','28':'Mississippi','29':'Missouri','37':'North Carolina','45':'South Carolina','47':'Tennessee','48':'Texas','51':'Virginia','54':'West Virginia'}
def base(y):
    if y==2020:
        b=pd.read_csv('S1860_on_2020.csv',dtype={'GISJOIN':str}).rename(columns={'S20':'S'})
        g=gpd.read_file('shp/US_county_2020.shp',columns=['GISJOIN','STATEFP']); g['cx']=g.geometry.centroid.x/1000; g['cy']=g.geometry.centroid.y/1000
        b=b.merge(g.drop(columns='geometry'),on='GISJOIN'); b['STATE']=b.STATEFP.map(FIPS)
    else: b=pd.read_csv(f'S1860_on_{y}.csv',dtype={'GISJOIN':str})
    b=b.merge(pd.read_csv(f'cotton_{y}.csv',dtype={'GISJOIN':str}),on='GISJOIN')
    b=b[b.STATE.isin(SS)&(b.cover>=0.9)&b.S.notna()&b.cotton.notna()].reset_index(drop=True)
    b['cz']=(b.cotton-b.cotton.mean())/b.cotton.std()
    D=np.sqrt((b.cx.values[:,None]-b.cx.values[None])**2+(b.cy.values[:,None]-b.cy.values[None])**2)
    N=np.linalg.cholesky(np.exp(-D/180)+1e-6*np.eye(len(D)))@rng.standard_normal((len(D),300))
    return b,N,dict(zip(b.GISJOIN,range(len(b))))
B={2020:base(2020)}
for y,(b,_,_) in B.items():
    r=np.corrcoef(b.S,b.cotton)[0,1]; print(f'{y}: n={len(b)} corr(S,cotton)={r:.2f}')
def reg(v,Z,y,w=None):
    w=np.ones(len(y)) if w is None else w; sw=np.sqrt(w)
    X=np.column_stack([v,Z])*sw[:,None]; yy=y*sw; bb=np.linalg.lstsq(X,yy,rcond=None)[0]; r=yy-X@bb
    return bb[0], bb[0]/np.sqrt(r@r/(len(y)-X.shape[1])*np.linalg.pinv(X.T@X)[0,0])
def run(name,d,by,ycol,w=None,fe='STATE'):
    b,N,idx=B[by]; d=d.merge(b[['GISJOIN','STATE','S','cz']],on='GISJOIN',suffixes=('_x','')); ii=d.GISJOIN.map(idx).values
    fe_=pd.get_dummies(d[fe].astype(str),drop_first=True).values.astype(float); one=np.ones(len(d)); yv=d[ycol].values; ww=None if w is None else d[w].values.astype(float)
    out={'outcome':name,'n':len(d)}
    for lab,Z in [('no_cotton',np.column_stack([one,fe_])),('cotton',np.column_stack([one,fe_,d.cz,d.cz**2]))]:
        be,t=reg(d.S.values,Z,yv,ww); tn=np.array([reg(N[ii,k],Z,yv,ww)[1] for k in range(300)])
        out[f'beta_{lab}']=round(be,3); out[f't_{lab}']=round(t,1); out[f'noise95_{lab}']=round(np.quantile(abs(tn),.95),1)
    out['kept_%']=round(100*out['beta_cotton']/out['beta_no_cotton']); return out

P='raw12/nhgis0012_csv/nhgis0012_'
def rd(k): return pd.read_csv(P+k+'_county.csv',encoding='latin-1',dtype={'GISJOIN':str},low_memory=False)
def S(df,pre,br,nums): return df[[f'{pre}{br}{n:03d}' for n in nums]].apply(pd.to_numeric,errors='coerce').sum(axis=1)
spec={1970:('ds99_1970','C2M',{'w':'AA','b':'AB'},range(1,21),list(range(7,11))+list(range(17,21)),[9,10,19,20]),
      1980:('ds111_1980','DX1',{'w':'AA','b':'AB'},list(range(15,29))+list(range(43,57)),list(range(22,29))+list(range(50,57)),[26,27,28,54,55,56]),
      1990:('ds125_1990','FF5',{'w':'AAA','b':'AAB'},range(1,31),list(range(8,16))+list(range(23,31)),[12,13,14,15,27,28,29,30]),
      2000:('ds153_2000','HX8',{'w':'AAAA','b':'AAAC'},range(1,33),list(range(9,17))+list(range(25,33)),[13,14,15,16,29,30,31,32])}
rows=[]
for yr,(k,pre,brs,tot,hs,ba) in spec.items():
    df=rd(k); d=pd.DataFrame({'GISJOIN':df.GISJOIN,'year':yr})
    for r,br in brs.items():
        T=S(df,pre,br,tot); d[f'n_{r}']=T; d[f'hs_{r}']=S(df,pre,br,hs)/T.where(T>0); d[f'ba_{r}']=S(df,pre,br,ba)/T.where(T>0)
    if yr==1990:
        for r,br in brs.items(): T=S(df,'FDL',br,range(1,13)); d[f'pov_{r}']=S(df,'FDL',br,range(7,13))/T.where(T>0)
    if yr==2000:
        for r,br in brs.items():
            cols=[c for c in df.columns if c.startswith('H35'+br)]; T=df[cols].apply(pd.to_numeric,errors='coerce').sum(axis=1)
            d[f'pov_{r}']=S(df,'H35',br,range(1,19))/T.where(T>0)
    rows.append(d)
e=pd.concat(rows); e['hs_gap']=e.hs_w-e.hs_b; e['ba_gap']=e.ba_w-e.ba_b
if 'pov_b' in e: e['pov_gap']=e.pov_b-e.pov_w
e.to_csv('modern_outcomes.csv',index=False)
res=[]
for yr in [1970,1980,1990,2000]:
    d=e[(e.year==yr)&(e.n_b>=50)]
    for col in ['hs_b','hs_gap','ba_b','ba_gap','pov_b','pov_gap']:
        if col not in d or d[col].notna().sum()<100: continue
        r=run(f'{col} {yr}',d[['GISJOIN',col]].dropna(),2020,col); r['mean']=round(d[col].mean(),3); res.append(r)
r=pd.DataFrame(res); print(r.drop(columns=['noise95_no_cotton']).to_string(index=False)); r.to_csv('modern_results.csv',index=False)
