import pandas as pd, numpy as np, geopandas as gpd, glob
def analyze(M, meta, S, label, wts=None):
    yrs=list(M.columns); X=M.values.copy()
    w=np.ones(len(X)) if wts is None else wts
    # within-state demeaning (weighted)
    st=meta.STATE.values; Xd=X.copy()
    for s in np.unique(st):
        m=st==s; Xd[m]-= (w[m,None]*X[m]).sum(0)/w[m].sum()
    sw=np.sqrt(w)[:,None]; U,sv,Vt=np.linalg.svd(Xd*sw,full_matrices=False); var=sv**2/(sv**2).sum()
    Ss=S.copy()
    for s in np.unique(st):
        m=st==s; Ss[m]-=(w[m]*S[m]).sum()/w[m].sum()
    c1=np.corrcoef(U[:,0],Ss*np.sqrt(w))[0,1]; sg=np.sign(c1)
    amp=sg*sv[0]*Vt[0]; amp=amp/np.abs(amp).max()
    q=pd.qcut(S,5,labels=False)
    G=pd.DataFrame(X,columns=yrs).mul(w,axis=0).groupby(q).sum().div(pd.Series(w).groupby(q).sum(),axis=0)
    mean=(X*w[:,None]).sum(0)/w.sum()
    print(f'\n=== {label}: n={len(X)}  mode variance {np.round(var[:3],3)}  mode1 corr with 1860={abs(c1):.2f}')
    print('  mode-1 amplitude:',dict(zip(yrs,np.round(amp,2))))
    rel=(G-G.mean()) if label.startswith('LOG') else G/mean
    print('  quintile '+('(log share minus mean log)' if label.startswith('LOG') else '/ mean')+':'); print(rel.round(2).to_string())
p=pd.read_csv('panel_nominal.csv',dtype={'GISJOIN':str}).dropna(subset=['bshare','S'])
yrs=sorted(p.YEAR.unique()); cnt=p.groupby('GISJOIN').YEAR.nunique(); p=p[p.GISJOIN.isin(cnt[cnt==len(yrs)].index)]
M=p.pivot_table(index=['GISJOIN','STATE'],columns='YEAR',values='bshare'); meta=M.index.to_frame(index=False)
S=p.drop_duplicates('GISJOIN').set_index('GISJOIN').S.reindex(meta.GISJOIN).values.astype(float)
T=p.pivot_table(index=['GISJOIN','STATE'],columns='YEAR',values='tot')
# 1) log scale (floor shares at 0.5% to avoid log 0)
analyze(np.log(M.clip(lower=0.005)),meta,S,'LOG Black share')
# 2) population-weighted (weight = 1870 county population)
analyze(M,meta,S,'POP-WEIGHTED (1870 pop)',wts=T[1870].values.astype(float))
