import pandas as pd, numpy as np
rows=[]
for yr in range(1959,1973):
    b=pd.read_csv(f'raw5/nhgis0005_csv/nhgis0005_ds230_{yr}_county.csv',encoding='latin-1',dtype={'GISJOIN':str})
    d=pd.read_csv(f'raw4/nhgis0004_csv/nhgis0004_ds230_{yr}_county.csv',encoding='latin-1',dtype={'GISJOIN':str})
    m=b[['GISJOIN','AGVU001','AGVU002']].merge(d[['GISJOIN','AGV0001','AGV0002']],on='GISJOIN')
    m.columns=['GISJOIN','bw','bn','dw','dn']; m['year']=yr; rows.append(m)
v=pd.concat(rows)
for c in ['bw','bn','dw','dn']: v[c]=pd.to_numeric(v[c],errors='coerce')
v.to_csv('imr_1959_72.csv',index=False)
s=pd.read_csv('s1860_nominal.csv',dtype={'GISJOIN':str})
SS=['Alabama','Arkansas','Delaware','Florida','Georgia','Kentucky','Louisiana','Maryland','Mississippi','Missouri','North Carolina','South Carolina','Tennessee','Texas','Virginia']
s=s[s.STATE.isin(SS)&s.S.notna()]
m=v.merge(s[['GISJOIN','STATE','S']],on='GISJOIN')
m['grp']=pd.cut(m.S,[-.01,.15,.40,1.0],labels=['low (<15%)','mid (15-40%)','high (>40%)'])
g=m.groupby(['year','grp'],observed=True)[['bn','dn','bw','dw']].sum()
g['imr_n']=1000*g.dn/g.bn; g['imr_w']=1000*g.dw/g.bw
print(g[['imr_n','imr_w']].unstack().round(1).to_string())
print(m.groupby('year')[['bn','dn']].sum().T)
