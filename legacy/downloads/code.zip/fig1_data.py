import pandas as pd, numpy as np, geopandas as gpd, glob, json
U='/mnt/user-data/uploads/'
def rd(pat):
    f=[x for x in glob.glob(U+'*'+pat)]; assert len(f)>=1,pat; return pd.read_csv(sorted(f)[0],encoding='latin-1',dtype={'GISJOIN':str})
ts=pd.read_csv(glob.glob(U+'*ts_nominal_county.csv')[0],encoding='latin-1',dtype=str)
tot=ts[['GISJOIN','YEAR','A00AA']].copy(); tot['YEAR']=tot.YEAR.astype(int); tot['tot']=pd.to_numeric(tot.A00AA,errors='coerce')
rows=[]
def add(y,df,cols):
    d=df[['GISJOIN']].copy(); d['black']=df[cols].apply(pd.to_numeric,errors='coerce').sum(axis=1); d['YEAR']=y; rows.append(d)
add(1870,rd('ds17_1870_county.csv'),['AK3002']); add(1880,rd('ds23_1880_county.csv'),['APP002'])
add(1890,rd('ds27_1890_county.csv'),['AV0007','AV0008']); add(1900,rd('ds31_1900_county.csv'),['AZ3003','AZ3004'])
add(1910,rd('ds37_1910_county.csv'),['A30003','A30004']); add(1920,rd('ds43_1920_county.csv'),['A8L005','A8L006'])
add(1930,rd('ds53_1930_county.csv'),['BDK003','BDK004']); add(1940,rd('ds77_1940_county.csv'),['BV2003','BV2004'])
add(1950,rd('nhgis0003_ds83_1950_county.csv'),['B1R%03d'%i for i in range(18,35)]); add(1960,rd('ds91_1960_county.csv'),['B5S002','B5S009'])
h=pd.concat(rows).merge(tot[['GISJOIN','YEAR','tot']],on=['GISJOIN','YEAR'])
g20=gpd.read_file('slavery/shp/US_county_2020.shp' if False else '/home/claude/slavery/shp/US_county_2020.shp')
FIPS=['01','05','10','12','13','21','22','24','28','29','37','45','47','48','51','54']
g20=g20[g20.STATEFP.isin(FIPS)][['GISJOIN','STATEFP','geometry']].reset_index(drop=True); g20['a20']=g20.area
shapes={1860:'US_county_1860_conflated',1900:'US_county_1900_conflated',1930:'US_county_1930_conflated'}
use={1870:1860,1880:1860,1890:1900,1900:1900,1910:1900,1920:1930,1930:1930,1940:1930,1950:1930,1960:1930}
cache={}
out={}
for y,sy in use.items():
    if sy not in cache:
        gs=gpd.read_file(f'/home/claude/slavery/shp/{shapes[sy]}.shp')[['GISJOIN','geometry']].to_crs(g20.crs); gs['as_']=gs.area
        cache[sy]=gpd.overlay(gs,g20[['GISJOIN','geometry']].rename(columns={'GISJOIN':'G20'}),how='intersection',keep_geom_type=True); cache[sy]['ia']=cache[sy].area
    x=cache[sy].merge(h[h.YEAR==y][['GISJOIN','black','tot']],on='GISJOIN',how='left')
    fr=x.ia/x.as_; x['b']=x.black*fr; x['t']=x.tot*fr; x['cov']=x.ia*x.tot.notna()
    c=x.groupby('G20').agg(b=('b','sum'),t=('t','sum'),cov=('cov','sum')).reset_index()
    c=c.merge(g20[['GISJOIN','a20']],left_on='G20',right_on='GISJOIN'); c=c[(c['cov']/c.a20>=0.8)&(c.t>0)]
    out[y]=dict(zip(c.G20,c.b/c.t)); print(y,len(out[y]))
seer=pd.read_csv('/home/claude/slavery/seer_county_race.csv',dtype={'stf':str,'cty':str,'GISJOIN':str})
seer=seer[seer.stf.isin(FIPS)&(seer.year>=1969)]
for y,d in seer.groupby('year'): out[int(y)]=dict(zip(d.GISJOIN,d.bshare))
print('SEER years',min(k for k in out if k>1965),'-',max(out),' counties 2024:',len(out[2024]))
# geometry -> SVG paths
gs=g20.copy(); gs['geometry']=gs.geometry.simplify(2500,preserve_topology=True)
minx,miny,maxx,maxy=gs.total_bounds; W=720; sc=W/(maxx-minx); H=int((maxy-miny)*sc)+1
def ring(c): return 'M'+'L'.join(f'{(x-minx)*sc:.1f},{(maxy-y)*sc:.1f}' for x,y in c)+'Z'
def path(geom):
    polys=[geom] if geom.geom_type=='Polygon' else list(geom.geoms)
    return ''.join(ring(p.exterior.coords) for p in polys)
ids=list(gs.GISJOIN); paths=[path(g) for g in gs.geometry]
st=gpd.GeoSeries(gs.dissolve(by='STATEFP').geometry.simplify(4000)); spaths=[path(g) for g in st]
years=sorted(out); vals={str(y):[None if ids[i] not in out[y] or not np.isfinite(out[y][ids[i]]) else round(float(out[y][ids[i]]),4) for i in range(len(ids))] for y in years}
means={str(y):float(np.nanmean([v for v in vals[str(y)] if v is not None])) for y in years}
json.dump(dict(W=W,H=H,ids=ids,paths=paths,states=spaths,years=years,vals=vals,means=means),open('/home/claude/slavery/fig1.json','w'))
print('W,H',W,H,' size MB',round(len(json.dumps(dict(paths=paths)))/1e6,2), 'means', {y:round(means[str(y)],3) for y in [1870,1930,1970,2024]})
mi=[i for i,k in enumerate(ids) if k=='G1302050'][0]; print('Mitchell', {y:vals[str(y)][mi] for y in [1870,1900,1970,2024]})
