import pandas as pd, numpy as np
cols=[(0,4),(4,6),(6,8),(8,11),(13,14),(18,26)]
it=pd.read_fwf('seer/out/us.1969_2024.20ages.adjusted.txt',colspecs=cols,names=['year','st','stf','cty','race','pop'],dtype={'stf':str,'cty':str},chunksize=4_000_000)
parts=[]
for ch in it:
    parts.append(ch.groupby(['year','stf','cty','race'],as_index=False)['pop'].sum())
d=pd.concat(parts).groupby(['year','stf','cty','race'],as_index=False)['pop'].sum()
w=d.pivot_table(index=['year','stf','cty'],columns='race',values='pop',fill_value=0).reset_index()
w.columns=['year','stf','cty','white','black','other']
w['tot']=w.white+w.black+w.other; w['bshare']=w.black/w.tot
w['GISJOIN']='G'+w.stf+'0'+w.cty+'0'
w.to_csv('seer_county_race.csv',index=False); print(w.shape, w.year.min(), w.year.max()); print(w[(w.stf=='13')&(w.cty.isin(['205','095','177']))&(w.year.isin([1970,1990,2024]))])
